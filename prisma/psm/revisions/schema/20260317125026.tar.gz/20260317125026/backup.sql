--
-- PostgreSQL database dump
--

\restrict x5jhk7A0V1HfdEO7DrDJ1teC6HcrdaaXSQ0Wtz1UgffIM5U8b1nHw1tZBHAM3mH

-- Dumped from database version 15.17
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg24.04+1)

-- Started on 2026-03-17 12:50:27 GMT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_migration_sid_fkey;
ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_pkey;
ALTER TABLE IF EXISTS ONLY sys.migration DROP CONSTRAINT IF EXISTS migration_pkey;
DROP TABLE IF EXISTS sys.revision;
DROP TABLE IF EXISTS sys.migration;
DROP FUNCTION IF EXISTS sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying);
DROP SCHEMA IF EXISTS sys;
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 65985)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 3421 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 6 (class 2615 OID 66117)
-- Name: sys; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA sys;


--
-- TOC entry 228 (class 1255 OID 66139)
-- Name: restore_serial(character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: sys; Owner: -
--

CREATE FUNCTION sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying) RETURNS TABLE(sequence character varying, counts bigint)
    LANGUAGE plpgsql
    AS $_$
        declare
        begin
   if exists(
     select *
       from pg_tables t
       where t.schemaname = schema
       and t.tablename = source
   ) then
       execute format( $statment$
       select max( %I ) from %I.%I
       $statment$, "from", schema, source )
       into counts;
   
       counts := coalesce( counts, 0 )+1;
       -- example district_id_seq
       sequence := coalesce( seq, format( '%I.%I', shadow, format( '%s_%s_seq', temp, "to" ) ) );
       perform setval( sequence::regclass, counts, false );
   end if;
   return next;
        end;
        $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 215 (class 1259 OID 66118)
-- Name: migration; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.migration (
    sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 66126)
-- Name: revision; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.revision (
    hash character varying NOT NULL,
    migration_sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    operation character varying NOT NULL,
    relation character varying NOT NULL,
    revision character varying
);


--
-- TOC entry 3414 (class 0 OID 66118)
-- Dependencies: 215
-- Data for Name: migration; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.migration (sid, date) FROM stdin;
\.


--
-- TOC entry 3415 (class 0 OID 66126)
-- Dependencies: 216
-- Data for Name: revision; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.revision (hash, migration_sid, date, operation, relation, revision) FROM stdin;
\.


--
-- TOC entry 3268 (class 2606 OID 66125)
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (sid);


--
-- TOC entry 3270 (class 2606 OID 66133)
-- Name: revision revision_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_pkey PRIMARY KEY (hash);


--
-- TOC entry 3271 (class 2606 OID 66134)
-- Name: revision revision_migration_sid_fkey; Type: FK CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_migration_sid_fkey FOREIGN KEY (migration_sid) REFERENCES sys.migration(sid);


--
-- TOC entry 3422 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2026-03-17 12:50:27 GMT

--
-- PostgreSQL database dump complete
--

\unrestrict x5jhk7A0V1HfdEO7DrDJ1teC6HcrdaaXSQ0Wtz1UgffIM5U8b1nHw1tZBHAM3mH

