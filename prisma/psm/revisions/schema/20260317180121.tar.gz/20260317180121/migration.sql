/*
      @PSM - Prisma SAFE MIGRATE
      @author zootakuxy
      @automation cli psm
      @mode migrate
      @date 2026-03-17T18:01:03.114Z
    */
insert into "sys".migration ( sid ) values ( 'oeh5p561' );
do $$ begin raise notice '%', 'CREATE SHADOW SCHEMA psm_shadow_kjua18w7'; end $$;
create schema "psm_shadow_kjua18w7";
do $$ begin raise notice '%', 'CREATE SHADOW SCHEMA psm_shadow_kjua18w7 OK!'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_0_users OF MODEL User'; end $$;
create table "psm_shadow_kjua18w7"."temp_0_users" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "name" varchar not null,
  "email" varchar not null,
  "password" varchar not null,
  "avatar" varchar,
  "role" varchar not null default 'user'::varchar,
  "status" int4 not null default '1'::int4,
  "created_at" timestamptz not null default now()::timestamptz,
  "updated_at" timestamptz not null,
  "created_by" int4,
  "updated_by" int4 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_0_users OF MODEL User OK'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_1_projects OF MODEL Project'; end $$;
create table "psm_shadow_kjua18w7"."temp_1_projects" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "name" varchar not null,
  "owner_id" int4 not null,
  "status" int4 not null default '1'::int4,
  "created_at" timestamptz not null default now()::timestamptz,
  "created_by" int4 not null,
  "updated_at" timestamptz not null,
  "updated_by" int4 not null 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_1_projects OF MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_2_collaborators OF MODEL Collaborator'; end $$;
create table "psm_shadow_kjua18w7"."temp_2_collaborators" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "user_id" int4 not null,
  "project_id" int4 not null,
  "role" varchar not null default 'viewer'::varchar,
  "start_at" timestamptz,
  "end_at" timestamptz,
  "status" int4 not null default '1'::int4,
  "created_at" timestamptz not null default now()::timestamptz,
  "created_by" int4 not null,
  "updated_at" timestamptz not null,
  "updated_by" int4 not null 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_2_collaborators OF MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_3_assets OF MODEL Asset'; end $$;
create table "psm_shadow_kjua18w7"."temp_3_assets" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "type" varchar not null,
  "name" varchar not null,
  "owner_id" int4 not null,
  "project_id" int4 not null,
  "parent_id" int4,
  "path" varchar not null,
  "configs" json,
  "binary" bytea,
  "text" varchar,
  "status" int4 not null default '1'::int4,
  "created_at" timestamptz not null default now()::timestamptz,
  "created_by" int4 not null,
  "updated_at" timestamptz not null,
  "updated_by" int4 not null 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_3_assets OF MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_4_invites OF MODEL Invite'; end $$;
create table "psm_shadow_kjua18w7"."temp_4_invites" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "token" varchar not null,
  "project_id" int4 not null,
  "created_by" int4 not null,
  "role" varchar not null default 'viewer'::varchar,
  "expires_at" timestamptz,
  "created_at" timestamptz not null default now()::timestamptz,
  "used_at" timestamptz,
  "used_by" int4 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_4_invites OF MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'CREATE TABLE temp_5_contributions OF MODEL Contribution'; end $$;
create table "psm_shadow_kjua18w7"."temp_5_contributions" (
  "id" serial not null,
  "uid" uuid not null default gen_random_uuid()::uuid,
  "user_id" int4 not null,
  "project_id" int4,
  "action" varchar not null,
  "details" json,
  "score" int4 not null default '1'::int4,
  "created_at" timestamptz not null default now()::timestamptz 
);
do $$ begin raise notice '%', 'CREATE TABLE temp_5_contributions OF MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL User'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'users'
            ) THEN
                LOCK TABLE "public"."users" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL User [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."users" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL User'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."users"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'users' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_0_users", to_jsonb(_t))).*
      FROM "public"."users" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_0_users"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'email' THEN s."email"
              ELSE NULL
          END AS "email",
CASE 
              WHEN original_json ? 'password' THEN s."password"
              ELSE NULL
          END AS "password",
CASE 
              WHEN original_json ? 'avatar' THEN s."avatar"
              ELSE NULL
          END AS "avatar",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'user'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_0_users" ( "id",  "uid",  "name",  "email",  "password",  "avatar",  "role",  "status",  "created_at",  "updated_at",  "created_by",  "updated_by")
        select 
             "id",  "uid",  "name",  "email",  "password",  "avatar",  "role",  "status",  "created_at",  "updated_at",  "created_by",  "updated_by"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_0_users", to_jsonb(_t))).*
      FROM "public"."users" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_0_users"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'email' THEN s."email"
              ELSE NULL
          END AS "email",
CASE 
              WHEN original_json ? 'password' THEN s."password"
              ELSE NULL
          END AS "password",
CASE 
              WHEN original_json ? 'avatar' THEN s."avatar"
              ELSE NULL
          END AS "avatar",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'user'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_0_users" ( "id",  "uid",  "name",  "email",  "password",  "avatar",  "role",  "status",  "created_at",  "updated_at",  "created_by",  "updated_by")
        select 
             "id",  "uid",  "name",  "email",  "password",  "avatar",  "role",  "status",  "created_at",  "updated_at",  "created_by",  "updated_by"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL User OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL User'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."users"', '2ff2bdce2fc342a5de23223b248a7ba9:e1cdcce75b4563f618e485454b6815dd8f64f3668e2d986a46fecfd238f7bbed', 'restore:data-"public"."users"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL User OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL Project'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'projects'
            ) THEN
                LOCK TABLE "public"."projects" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL Project [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."projects" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Project'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."projects"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'projects' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_1_projects", to_jsonb(_t))).*
      FROM "public"."projects" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_1_projects"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'owner_id' THEN s."owner_id"
              ELSE NULL
          END AS "owner_id",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_1_projects" ( "id",  "uid",  "name",  "owner_id",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "name",  "owner_id",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_1_projects", to_jsonb(_t))).*
      FROM "public"."projects" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_1_projects"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'owner_id' THEN s."owner_id"
              ELSE NULL
          END AS "owner_id",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_1_projects" ( "id",  "uid",  "name",  "owner_id",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "name",  "owner_id",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Project'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."projects"', '2ff2bdce2fc342a5de23223b248a7ba9:3b3d4ff29dd00e4918c50e12030a6d236f9aeaa1c9a3c7e55f7527911efd16fb', 'restore:data-"public"."projects"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL Collaborator'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'collaborators'
            ) THEN
                LOCK TABLE "public"."collaborators" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL Collaborator [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."collaborators" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Collaborator'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."collaborators"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'collaborators' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_2_collaborators", to_jsonb(_t))).*
      FROM "public"."collaborators" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_2_collaborators"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'user_id' THEN s."user_id"
              ELSE NULL
          END AS "user_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'viewer'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'start_at' THEN s."start_at"
              ELSE NULL
          END AS "start_at",
CASE 
              WHEN original_json ? 'end_at' THEN s."end_at"
              ELSE NULL
          END AS "end_at",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_2_collaborators" ( "id",  "uid",  "user_id",  "project_id",  "role",  "start_at",  "end_at",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "user_id",  "project_id",  "role",  "start_at",  "end_at",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_2_collaborators", to_jsonb(_t))).*
      FROM "public"."collaborators" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_2_collaborators"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'user_id' THEN s."user_id"
              ELSE NULL
          END AS "user_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'viewer'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'start_at' THEN s."start_at"
              ELSE NULL
          END AS "start_at",
CASE 
              WHEN original_json ? 'end_at' THEN s."end_at"
              ELSE NULL
          END AS "end_at",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_2_collaborators" ( "id",  "uid",  "user_id",  "project_id",  "role",  "start_at",  "end_at",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "user_id",  "project_id",  "role",  "start_at",  "end_at",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Collaborator'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."collaborators"', '2ff2bdce2fc342a5de23223b248a7ba9:e3b14f40b30a0d9549ed21c976f3f0ff5f2b789cbc5843d7847efd371daf8b34', 'restore:data-"public"."collaborators"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL Asset'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'assets'
            ) THEN
                LOCK TABLE "public"."assets" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL Asset [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."assets" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Asset'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."assets"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'assets' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_3_assets", to_jsonb(_t))).*
      FROM "public"."assets" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_3_assets"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'type' THEN s."type"
              ELSE NULL
          END AS "type",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'owner_id' THEN s."owner_id"
              ELSE NULL
          END AS "owner_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'parent_id' THEN s."parent_id"
              ELSE NULL
          END AS "parent_id",
CASE 
              WHEN original_json ? 'path' THEN s."path"
              ELSE NULL
          END AS "path",
CASE 
              WHEN original_json ? 'configs' THEN s."configs"
              ELSE NULL
          END AS "configs",
CASE 
              WHEN original_json ? 'binary' THEN s."binary"
              ELSE NULL
          END AS "binary",
CASE 
              WHEN original_json ? 'text' THEN s."text"
              ELSE NULL
          END AS "text",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_3_assets" ( "id",  "uid",  "type",  "name",  "owner_id",  "project_id",  "parent_id",  "path",  "configs",  "binary",  "text",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "type",  "name",  "owner_id",  "project_id",  "parent_id",  "path",  "configs",  "binary",  "text",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_3_assets", to_jsonb(_t))).*
      FROM "public"."assets" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_3_assets"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'type' THEN s."type"
              ELSE NULL
          END AS "type",
CASE 
              WHEN original_json ? 'name' THEN s."name"
              ELSE NULL
          END AS "name",
CASE 
              WHEN original_json ? 'owner_id' THEN s."owner_id"
              ELSE NULL
          END AS "owner_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'parent_id' THEN s."parent_id"
              ELSE NULL
          END AS "parent_id",
CASE 
              WHEN original_json ? 'path' THEN s."path"
              ELSE NULL
          END AS "path",
CASE 
              WHEN original_json ? 'configs' THEN s."configs"
              ELSE NULL
          END AS "configs",
CASE 
              WHEN original_json ? 'binary' THEN s."binary"
              ELSE NULL
          END AS "binary",
CASE 
              WHEN original_json ? 'text' THEN s."text"
              ELSE NULL
          END AS "text",
CASE 
              WHEN original_json ? 'status' THEN s."status"
              ELSE 1
          END AS "status",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'updated_at' THEN s."updated_at"
              ELSE NULL
          END AS "updated_at",
CASE 
              WHEN original_json ? 'updated_by' THEN s."updated_by"
              ELSE NULL
          END AS "updated_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_3_assets" ( "id",  "uid",  "type",  "name",  "owner_id",  "project_id",  "parent_id",  "path",  "configs",  "binary",  "text",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by")
        select 
             "id",  "uid",  "type",  "name",  "owner_id",  "project_id",  "parent_id",  "path",  "configs",  "binary",  "text",  "status",  "created_at",  "created_by",  "updated_at",  "updated_by"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Asset'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."assets"', '2ff2bdce2fc342a5de23223b248a7ba9:8e5632b2e35c0a24fd2ac367c1c6ea399134bf0a14e1559b4c03832d7120b871', 'restore:data-"public"."assets"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL Invite'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'invites'
            ) THEN
                LOCK TABLE "public"."invites" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL Invite [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."invites" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Invite'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."invites"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'invites' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_4_invites", to_jsonb(_t))).*
      FROM "public"."invites" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_4_invites"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'token' THEN s."token"
              ELSE NULL
          END AS "token",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'viewer'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'expires_at' THEN s."expires_at"
              ELSE NULL
          END AS "expires_at",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'used_at' THEN s."used_at"
              ELSE NULL
          END AS "used_at",
CASE 
              WHEN original_json ? 'used_by' THEN s."used_by"
              ELSE NULL
          END AS "used_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_4_invites" ( "id",  "uid",  "token",  "project_id",  "created_by",  "role",  "expires_at",  "created_at",  "used_at",  "used_by")
        select 
             "id",  "uid",  "token",  "project_id",  "created_by",  "role",  "expires_at",  "created_at",  "used_at",  "used_by"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_4_invites", to_jsonb(_t))).*
      FROM "public"."invites" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_4_invites"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'token' THEN s."token"
              ELSE NULL
          END AS "token",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'created_by' THEN s."created_by"
              ELSE NULL
          END AS "created_by",
CASE 
              WHEN original_json ? 'role' THEN s."role"
              ELSE 'viewer'::varchar
          END AS "role",
CASE 
              WHEN original_json ? 'expires_at' THEN s."expires_at"
              ELSE NULL
          END AS "expires_at",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at",
CASE 
              WHEN original_json ? 'used_at' THEN s."used_at"
              ELSE NULL
          END AS "used_at",
CASE 
              WHEN original_json ? 'used_by' THEN s."used_by"
              ELSE NULL
          END AS "used_by"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_4_invites" ( "id",  "uid",  "token",  "project_id",  "created_by",  "role",  "expires_at",  "created_at",  "used_at",  "used_by")
        select 
             "id",  "uid",  "token",  "project_id",  "created_by",  "role",  "expires_at",  "created_at",  "used_at",  "used_by"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Invite'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."invites"', '2ff2bdce2fc342a5de23223b248a7ba9:391ca5ec35f269b55c907b0dfac43a4cbf2083344e9caecd7cf16f4e0ddef1b5', 'restore:data-"public"."invites"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'PREPARING LOCK FOR MODEL Contribution'; end $$;
DO $$
        BEGIN
            IF EXISTS (
                SELECT 1 
                FROM pg_catalog.pg_class c
                JOIN pg_catalog.pg_namespace n ON n.oid = c.relnamespace
                WHERE n.nspname = 'public'
                AND c.relname = 'contributions'
            ) THEN
                LOCK TABLE "public"."contributions" IN SHARE MODE;
                RAISE NOTICE 'LOCK TABLE FOR SHARE MODE TO MODEL Contribution [OK]';
            ELSE
                RAISE NOTICE 'TABLE "public"."contributions" NOT FOUND, SKIPPING LOCK';
            END IF;
        END $$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Contribution'; end $$;
do $$
  declare
    _revision character varying := null::character varying;
    _relation character varying := '"public"."contributions"'::character varying;
    ___whenX1025475 boolean;
  begin
    if not exists( select 1 from pg_catalog.pg_tables t where t.tablename = 'contributions' and t.schemaname = 'public' ) then
      return;
    end if;
    ___whenX1025475 := (true);
    if not coalesce( ___whenX1025475, true ) then
      return;
    end if;
    if _revision is not null and not exists(
      select 1
        from "sys".revision r
        where r.revision = _revision
          and operation = 'restore:data'
          and relation = _relation
    ) then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_5_contributions", to_jsonb(_t))).*
      FROM "public"."contributions" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_5_contributions"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'user_id' THEN s."user_id"
              ELSE NULL
          END AS "user_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'action' THEN s."action"
              ELSE NULL
          END AS "action",
CASE 
              WHEN original_json ? 'details' THEN s."details"
              ELSE NULL
          END AS "details",
CASE 
              WHEN original_json ? 'score' THEN s."score"
              ELSE 1
          END AS "score",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_5_contributions" ( "id",  "uid",  "user_id",  "project_id",  "action",  "details",  "score",  "created_at")
        select 
             "id",  "uid",  "user_id",  "project_id",  "action",  "details",  "score",  "created_at"
          from __restore r;
    elsif _revision is null then 
      with __restore as (
  WITH __source AS (
      SELECT
          to_jsonb(_t) AS original_json,
          (jsonb_populate_record(null::"psm_shadow_kjua18w7"."temp_5_contributions", to_jsonb(_t))).*
      FROM "public"."contributions" _t
  )
  SELECT
      CASE 
              WHEN original_json ? 'id' THEN s."id"
              ELSE nextval(pg_get_serial_sequence('"psm_shadow_kjua18w7"."temp_5_contributions"', 'id')::regclass)
          END AS "id",
CASE 
              WHEN original_json ? 'uid' THEN s."uid"
              ELSE gen_random_uuid()
          END AS "uid",
CASE 
              WHEN original_json ? 'user_id' THEN s."user_id"
              ELSE NULL
          END AS "user_id",
CASE 
              WHEN original_json ? 'project_id' THEN s."project_id"
              ELSE NULL
          END AS "project_id",
CASE 
              WHEN original_json ? 'action' THEN s."action"
              ELSE NULL
          END AS "action",
CASE 
              WHEN original_json ? 'details' THEN s."details"
              ELSE NULL
          END AS "details",
CASE 
              WHEN original_json ? 'score' THEN s."score"
              ELSE 1
          END AS "score",
CASE 
              WHEN original_json ? 'created_at' THEN s."created_at"
              ELSE now()
          END AS "created_at"
  FROM __source s
      ) insert into "psm_shadow_kjua18w7"."temp_5_contributions" ( "id",  "uid",  "user_id",  "project_id",  "action",  "details",  "score",  "created_at")
        select 
             "id",  "uid",  "user_id",  "project_id",  "action",  "details",  "score",  "created_at"
          from __restore r;
    else 
      raise exception 'cannot restore revision';
    end if;
  end;
$$;
do $$ begin raise notice '%', 'RESTORE BACKUP FOR MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Contribution'; end $$;
insert into "sys".revision ( "revision", "relation", "hash", "operation", "migration_sid" ) values ( null, '"public"."contributions"', '2ff2bdce2fc342a5de23223b248a7ba9:511485b6130b7483446f2e0cf53b3524c18192ac2f5377d86fa08320b9bfbcd1', 'restore:data-"public"."contributions"', 'oeh5p561' );
do $$ begin raise notice '%', 'REGISTRY RESTORE OF BACKUP FOR MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL User'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'users'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_0_users'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL User OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Project'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'projects'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_1_projects'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Collaborator'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'collaborators'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_2_collaborators'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Asset'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'assets'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_3_assets'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Invite'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'invites'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_4_invites'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Contribution'; end $$;
select * from "sys".restore_serial(
   schema := 'public'::varchar,
   source := 'contributions'::varchar,
   shadow := 'psm_shadow_kjua18w7'::varchar,
   temp := 'temp_5_contributions'::varchar,
   "from" := 'id'::varchar,
   "to" := 'id'::varchar,
   "seq" := null::varchar
);
do $$ begin raise notice '%', 'RESTORE SEQUENCE OF FIELD id FROM MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_users_id_by_prisma" OF MODEL User'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_0_users" add constraint "pk_users_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_users_id_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_projects_id_by_prisma" OF MODEL Project'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_1_projects" add constraint "pk_projects_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_projects_id_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_collaborators_id_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_2_collaborators" add constraint "pk_collaborators_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_collaborators_id_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_assets_id_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "pk_assets_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_assets_id_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_invites_id_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "pk_invites_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_invites_id_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_contributions_id_by_prisma" OF MODEL Contribution'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_5_contributions" add constraint "pk_contributions_id_by_prisma" primary key ("id");
do $$ begin raise notice '%', 'CREATE PRIMARY KEY "pk_contributions_id_by_prisma" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_users_uid_by_prisma" OF MODEL User'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_0_users" add constraint "uk_users_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_users_uid_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_users_email_by_prisma" OF MODEL User'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_0_users" add constraint "uk_users_email_by_prisma" unique ("email");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_users_email_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_projects_uid_by_prisma" OF MODEL Project'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_1_projects" add constraint "uk_projects_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_projects_uid_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_projects_name_by_prisma" OF MODEL Project'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_1_projects" add constraint "uk_projects_name_by_prisma" unique ("name");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_projects_name_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_collaborators_uid_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_2_collaborators" add constraint "uk_collaborators_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_collaborators_uid_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_collaborators_user_id_project_id_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_2_collaborators" add constraint "uk_collaborators_user_id_project_id_by_prisma" unique ("user_id", "project_id");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_collaborators_user_id_project_id_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_assets_uid_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "uk_assets_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_assets_uid_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_assets_project_id_path_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "uk_assets_project_id_path_by_prisma" unique ("project_id", "path");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_assets_project_id_path_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_invites_uid_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "uk_invites_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_invites_uid_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_invites_token_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "uk_invites_token_by_prisma" unique ("token");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_invites_token_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_contributions_uid_by_prisma" OF MODEL Contribution'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_5_contributions" add constraint "uk_contributions_uid_by_prisma" unique ("uid");
do $$ begin raise notice '%', 'CREATE UNIQUE KEY "uk_contributions_uid_by_prisma" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "Owner" OF MODEL Project'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_1_projects" add constraint "Owner" foreign key ("owner_id") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "Owner" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "CollaboratorProject" OF MODEL Collaborator'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_2_collaborators" add constraint "CollaboratorProject" foreign key ("project_id") references "psm_shadow_kjua18w7"."temp_1_projects" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "CollaboratorProject" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "CollaboratorUser" OF MODEL Collaborator'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_2_collaborators" add constraint "CollaboratorUser" foreign key ("user_id") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "CollaboratorUser" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetOwner" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "AssetOwner" foreign key ("owner_id") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetOwner" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetsProject" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "AssetsProject" foreign key ("project_id") references "psm_shadow_kjua18w7"."temp_1_projects" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetsProject" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetChildren" OF MODEL Asset'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_3_assets" add constraint "AssetChildren" foreign key ("parent_id") references "psm_shadow_kjua18w7"."temp_3_assets" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "AssetChildren" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteToProject" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "InviteToProject" foreign key ("project_id") references "psm_shadow_kjua18w7"."temp_1_projects" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteToProject" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteCreator" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "InviteCreator" foreign key ("created_by") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteCreator" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteUsedBy" OF MODEL Invite'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_4_invites" add constraint "InviteUsedBy" foreign key ("used_by") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "InviteUsedBy" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "Contributor" OF MODEL Contribution'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_5_contributions" add constraint "Contributor" foreign key ("user_id") references "psm_shadow_kjua18w7"."temp_0_users" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "Contributor" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "ContributionToProject" OF MODEL Contribution'; end $$;
alter table if exists "psm_shadow_kjua18w7"."temp_5_contributions" add constraint "ContributionToProject" foreign key ("project_id") references "psm_shadow_kjua18w7"."temp_1_projects" ( "id" );
do $$ begin raise notice '%', 'CREATE FOREIGN KEY "ContributionToProject" OF MODEL Contribution OK!'; end $$;
create schema if not exists "public";
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "Owner" OF MODEL Project'; end $$;
alter table if exists "public"."projects" drop constraint if exists "Owner" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "Owner" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "CollaboratorProject" OF MODEL Collaborator'; end $$;
alter table if exists "public"."collaborators" drop constraint if exists "CollaboratorProject" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "CollaboratorProject" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "CollaboratorUser" OF MODEL Collaborator'; end $$;
alter table if exists "public"."collaborators" drop constraint if exists "CollaboratorUser" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "CollaboratorUser" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetOwner" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "AssetOwner" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetOwner" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetsProject" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "AssetsProject" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetsProject" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetChildren" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "AssetChildren" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "AssetChildren" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteToProject" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "InviteToProject" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteToProject" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteCreator" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "InviteCreator" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteCreator" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteUsedBy" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "InviteUsedBy" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "InviteUsedBy" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "Contributor" OF MODEL Contribution'; end $$;
alter table if exists "public"."contributions" drop constraint if exists "Contributor" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "Contributor" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "ContributionToProject" OF MODEL Contribution'; end $$;
alter table if exists "public"."contributions" drop constraint if exists "ContributionToProject" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "ContributionToProject" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_users_uid_by_prisma" OF MODEL User'; end $$;
alter table if exists "public"."users" drop constraint if exists "uk_users_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_users_uid_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_users_email_by_prisma" OF MODEL User'; end $$;
alter table if exists "public"."users" drop constraint if exists "uk_users_email_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_users_email_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_projects_uid_by_prisma" OF MODEL Project'; end $$;
alter table if exists "public"."projects" drop constraint if exists "uk_projects_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_projects_uid_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_projects_name_by_prisma" OF MODEL Project'; end $$;
alter table if exists "public"."projects" drop constraint if exists "uk_projects_name_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_projects_name_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_collaborators_uid_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "public"."collaborators" drop constraint if exists "uk_collaborators_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_collaborators_uid_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_collaborators_user_id_project_id_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "public"."collaborators" drop constraint if exists "uk_collaborators_user_id_project_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_collaborators_user_id_project_id_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_assets_uid_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "uk_assets_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_assets_uid_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_assets_project_id_path_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "uk_assets_project_id_path_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_assets_project_id_path_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_invites_uid_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "uk_invites_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_invites_uid_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_invites_token_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "uk_invites_token_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_invites_token_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_contributions_uid_by_prisma" OF MODEL Contribution'; end $$;
alter table if exists "public"."contributions" drop constraint if exists "uk_contributions_uid_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "uk_contributions_uid_by_prisma" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_users_id_by_prisma" OF MODEL User'; end $$;
alter table if exists "public"."users" drop constraint if exists "pk_users_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_users_id_by_prisma" OF MODEL User OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_projects_id_by_prisma" OF MODEL Project'; end $$;
alter table if exists "public"."projects" drop constraint if exists "pk_projects_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_projects_id_by_prisma" OF MODEL Project OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_collaborators_id_by_prisma" OF MODEL Collaborator'; end $$;
alter table if exists "public"."collaborators" drop constraint if exists "pk_collaborators_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_collaborators_id_by_prisma" OF MODEL Collaborator OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_assets_id_by_prisma" OF MODEL Asset'; end $$;
alter table if exists "public"."assets" drop constraint if exists "pk_assets_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_assets_id_by_prisma" OF MODEL Asset OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_invites_id_by_prisma" OF MODEL Invite'; end $$;
alter table if exists "public"."invites" drop constraint if exists "pk_invites_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_invites_id_by_prisma" OF MODEL Invite OK!'; end $$;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_contributions_id_by_prisma" OF MODEL Contribution'; end $$;
alter table if exists "public"."contributions" drop constraint if exists "pk_contributions_id_by_prisma" cascade;
do $$ begin raise notice '%', 'DROP CONSTRAINT KEY "pk_contributions_id_by_prisma" OF MODEL Contribution OK!'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.users OF MODEL User'; end $$;
drop table if exists "public"."users" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.users OF MODEL User OK'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.projects OF MODEL Project'; end $$;
drop table if exists "public"."projects" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.projects OF MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.collaborators OF MODEL Collaborator'; end $$;
drop table if exists "public"."collaborators" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.collaborators OF MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.assets OF MODEL Asset'; end $$;
drop table if exists "public"."assets" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.assets OF MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.invites OF MODEL Invite'; end $$;
drop table if exists "public"."invites" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.invites OF MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'DROP TABLE public.contributions OF MODEL Contribution'; end $$;
drop table if exists "public"."contributions" cascade;
do $$ begin raise notice '%', 'DROP TABLE public.contributions OF MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_0_users OF MODEL User'; end $$;
alter table "psm_shadow_kjua18w7"."temp_0_users" set schema "public";
alter table "public"."temp_0_users" rename to "users" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_0_users OF MODEL User OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_1_projects OF MODEL Project'; end $$;
alter table "psm_shadow_kjua18w7"."temp_1_projects" set schema "public";
alter table "public"."temp_1_projects" rename to "projects" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_1_projects OF MODEL Project OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_2_collaborators OF MODEL Collaborator'; end $$;
alter table "psm_shadow_kjua18w7"."temp_2_collaborators" set schema "public";
alter table "public"."temp_2_collaborators" rename to "collaborators" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_2_collaborators OF MODEL Collaborator OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_3_assets OF MODEL Asset'; end $$;
alter table "psm_shadow_kjua18w7"."temp_3_assets" set schema "public";
alter table "public"."temp_3_assets" rename to "assets" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_3_assets OF MODEL Asset OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_4_invites OF MODEL Invite'; end $$;
alter table "psm_shadow_kjua18w7"."temp_4_invites" set schema "public";
alter table "public"."temp_4_invites" rename to "invites" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_4_invites OF MODEL Invite OK'; end $$;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_5_contributions OF MODEL Contribution'; end $$;
alter table "psm_shadow_kjua18w7"."temp_5_contributions" set schema "public";
alter table "public"."temp_5_contributions" rename to "contributions" ;
do $$ begin raise notice '%', 'ALLOCATE TABLE temp_5_contributions OF MODEL Contribution OK'; end $$;
do $$ begin raise notice '%', 'DROP SHADOW SCHEMA psm_shadow_kjua18w7'; end $$;
drop schema "psm_shadow_kjua18w7" cascade;
do $$ begin raise notice '%', 'DROP SHADOW SCHEMA psm_shadow_kjua18w7 OK!'; end $$;