--
-- PostgreSQL database dump
--

\restrict XrnkwjDgUUdfjElXhdetyNng6HGLtHdhUrUtOeo5C9Kw3z1fIdydfGXnsxgDjSd

-- Dumped from database version 15.17
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg24.04+1)

-- Started on 2026-03-17 16:05:50 GMT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_migration_sid_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS "Owner";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteUsedBy";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteToProject";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteCreator";
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS "Contributor";
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS "ContributionToProject";
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS "CollaboratorUser";
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS "CollaboratorProject";
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS "AssetsProject";
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS "AssetOwner";
ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_pkey;
ALTER TABLE IF EXISTS ONLY sys.migration DROP CONSTRAINT IF EXISTS migration_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk_users_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk_users_email_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS uk_projects_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS uk_projects_name_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS uk_invites_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS uk_invites_token_by_prisma;
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS uk_contributions_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS uk_collaborators_user_id_project_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS uk_collaborators_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS uk_assets_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS uk_assets_project_id_path_by_prisma;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS pk_projects_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS pk_invites_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS pk_contributions_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS pk_collaborators_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS pk_assets_id_by_prisma;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.invites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contributions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.collaborators ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS sys.revision;
DROP TABLE IF EXISTS sys.migration;
DROP SEQUENCE IF EXISTS public.temp_5_contributions_id_seq;
DROP SEQUENCE IF EXISTS public.temp_4_invites_id_seq;
DROP SEQUENCE IF EXISTS public.temp_3_assets_id_seq;
DROP SEQUENCE IF EXISTS public.temp_2_collaborators_id_seq;
DROP SEQUENCE IF EXISTS public.temp_1_projects_id_seq;
DROP SEQUENCE IF EXISTS public.temp_0_users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.invites;
DROP TABLE IF EXISTS public.contributions;
DROP TABLE IF EXISTS public.collaborators;
DROP TABLE IF EXISTS public.assets;
DROP FUNCTION IF EXISTS sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying);
DROP SCHEMA IF EXISTS sys;
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 65985)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 3533 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 6 (class 2615 OID 66117)
-- Name: sys; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA sys;


--
-- TOC entry 240 (class 1255 OID 66139)
-- Name: restore_serial(character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: sys; Owner: -
--

CREATE FUNCTION sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying) RETURNS TABLE(sequence character varying, counts bigint)
    LANGUAGE plpgsql
    AS $_$
        declare
        begin
   if exists(
     select *
       from pg_tables t
       where t.schemaname = schema
       and t.tablename = source
   ) then
       execute format( $statment$
       select max( %I ) from %I.%I
       $statment$, "from", schema, source )
       into counts;
   
       counts := coalesce( counts, 0 )+1;
       -- example district_id_seq
       sequence := coalesce( seq, format( '%I.%I', shadow, format( '%s_%s_seq', temp, "to" ) ) );
       perform setval( sequence::regclass, counts, false );
   end if;
   return next;
        end;
        $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 67502)
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying NOT NULL,
    name character varying NOT NULL,
    owner_id integer NOT NULL,
    project_id integer NOT NULL,
    path character varying NOT NULL,
    configs json,
    "binary" bytea,
    text character varying,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 67491)
-- Name: collaborators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collaborators (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    project_id integer NOT NULL,
    role character varying DEFAULT 'viewer'::character varying NOT NULL,
    start_at timestamp with time zone,
    end_at timestamp with time zone,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 67522)
-- Name: contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contributions (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    project_id integer,
    action character varying NOT NULL,
    details json,
    score integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 67512)
-- Name: invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invites (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying NOT NULL,
    project_id integer NOT NULL,
    created_by integer NOT NULL,
    role character varying DEFAULT 'viewer'::character varying NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone,
    used_by integer
);


--
-- TOC entry 220 (class 1259 OID 67481)
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    owner_id integer NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 67470)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    avatar character varying,
    role character varying DEFAULT 'user'::character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer,
    updated_by integer
);


--
-- TOC entry 217 (class 1259 OID 67469)
-- Name: temp_0_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_0_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 217
-- Name: temp_0_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_0_users_id_seq OWNED BY public.users.id;


--
-- TOC entry 219 (class 1259 OID 67480)
-- Name: temp_1_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_1_projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 219
-- Name: temp_1_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_1_projects_id_seq OWNED BY public.projects.id;


--
-- TOC entry 221 (class 1259 OID 67490)
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_2_collaborators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 221
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_2_collaborators_id_seq OWNED BY public.collaborators.id;


--
-- TOC entry 223 (class 1259 OID 67501)
-- Name: temp_3_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_3_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 223
-- Name: temp_3_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_3_assets_id_seq OWNED BY public.assets.id;


--
-- TOC entry 225 (class 1259 OID 67511)
-- Name: temp_4_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_4_invites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 225
-- Name: temp_4_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_4_invites_id_seq OWNED BY public.invites.id;


--
-- TOC entry 227 (class 1259 OID 67521)
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_5_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 227
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_5_contributions_id_seq OWNED BY public.contributions.id;


--
-- TOC entry 215 (class 1259 OID 66118)
-- Name: migration; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.migration (
    sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 66126)
-- Name: revision; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.revision (
    hash character varying NOT NULL,
    migration_sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    operation character varying NOT NULL,
    relation character varying NOT NULL,
    revision character varying
);


--
-- TOC entry 3311 (class 2604 OID 67505)
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.temp_3_assets_id_seq'::regclass);


--
-- TOC entry 3306 (class 2604 OID 67494)
-- Name: collaborators id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators ALTER COLUMN id SET DEFAULT nextval('public.temp_2_collaborators_id_seq'::regclass);


--
-- TOC entry 3319 (class 2604 OID 67525)
-- Name: contributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions ALTER COLUMN id SET DEFAULT nextval('public.temp_5_contributions_id_seq'::regclass);


--
-- TOC entry 3315 (class 2604 OID 67515)
-- Name: invites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites ALTER COLUMN id SET DEFAULT nextval('public.temp_4_invites_id_seq'::regclass);


--
-- TOC entry 3302 (class 2604 OID 67484)
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.temp_1_projects_id_seq'::regclass);


--
-- TOC entry 3297 (class 2604 OID 67473)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.temp_0_users_id_seq'::regclass);


--
-- TOC entry 3523 (class 0 OID 67502)
-- Dependencies: 224
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, uid, type, name, owner_id, project_id, path, configs, "binary", text, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5d-e811-71cc-ad8a-dd777874f358	schema:raw	main.prisma	1	1	prisma/schema.prisma	{}	\N	model User {\n  id        Int      @id @default(autoincrement())\n  email     String   @unique\n  password  String\n  name      String?\n  role      Role     @default(USER)\n  profile   Profile?\n  createdAt DateTime @default(now())\n}\n\nmodel Profile {\n  id     Int    @id @default(autoincrement())\n  bio    String\n  user   User   @relation(fields: [userId], references: [id])\n  userId Int    @unique\n}\n\nenum Role {\n  USER\n  ADMIN\n}	1	2026-03-17 15:15:38.641+00	1	2026-03-17 15:16:20.502+00	1
2	019cfc5d-e8a9-711b-9fdc-75a2fa31045b	project:config	config	1	1	.studio/config.json	{"databaseConfig":{"type":"postgresql","url":"","infraMode":"docker","useFields":false},"activeEnvironmentId":null,"activeFlowId":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","openFlowIds":["482e99b0-4d7d-4d4e-8f82-58c1cfae6750"],"useDirectSchema":true,"folders":[],"environments":[],"tests":[],"history":[]}	\N	\N	1	2026-03-17 15:15:38.793+00	1	2026-03-17 15:16:01.661+00	1
3	019cfc5e-41df-74aa-9d76-c1eb45879678	project:flow	Novo Fluxo 1	1	1	.studio/flows/482e99b0-4d7d-4d4e-8f82-58c1cfae6750.json	{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","folderId":null,"nodes":[{"id":"op-1773760558542","type":"operation","position":{"x":-187.46469916276374,"y":16.308584631885992},"data":{"id":"op-1773760558542","method":"Sets","versions":{"graphql":true,"rest":true}},"width":256,"height":173,"selected":true,"positionAbsolute":{"x":-187.46469916276374,"y":16.308584631885992},"dragging":false},{"id":"model-1773760559926","type":"model","position":{"x":158.26185031135913,"y":-55.5155781068423},"data":{"id":"model-1773760559926","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":158.26185031135913,"y":-55.5155781068423},"dragging":false}],"edges":[{"source":"op-1773760558542","sourceHandle":"right","target":"model-1773760559926","targetHandle":"in-left","id":"edge-1773760572373","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","operationType":"Get","conditions":[]}}],"createdAt":1773760557006}	\N	\N	1	2026-03-17 15:16:01.631+00	1	2026-03-17 15:35:58.927+00	1
\.


--
-- TOC entry 3521 (class 0 OID 67491)
-- Dependencies: 222
-- Data for Name: collaborators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collaborators (id, uid, user_id, project_id, role, start_at, end_at, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5a-e9de-75db-abc9-77ae3f9a6d23	1	1	owner	\N	\N	1	2026-03-17 15:12:22.494+00	1	2026-03-17 15:12:22.494+00	1
2	019cfc5c-2db7-7460-a6d9-39f2552bd731	1	2	owner	\N	\N	1	2026-03-17 15:13:45.399+00	1	2026-03-17 15:13:45.399+00	1
3	019cfc5c-b0b7-77fb-92ea-4f74cac42be4	1	3	owner	\N	\N	1	2026-03-17 15:14:18.935+00	1	2026-03-17 15:14:18.935+00	1
\.


--
-- TOC entry 3527 (class 0 OID 67522)
-- Dependencies: 228
-- Data for Name: contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contributions (id, uid, user_id, project_id, action, details, score, created_at) FROM stdin;
\.


--
-- TOC entry 3525 (class 0 OID 67512)
-- Dependencies: 226
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invites (id, uid, token, project_id, created_by, role, expires_at, created_at, used_at, used_by) FROM stdin;
\.


--
-- TOC entry 3519 (class 0 OID 67481)
-- Dependencies: 220
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, uid, name, owner_id, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5a-e9d9-72b8-b27b-a7dfbb87c3a0	Siage	1	1	2026-03-17 15:12:22.489+00	1	2026-03-17 15:12:22.489+00	1
2	019cfc5c-2db3-72d6-b1d7-16a8f6a58c40	S1	1	1	2026-03-17 15:13:45.395+00	1	2026-03-17 15:13:45.395+00	1
3	019cfc5c-b0b4-71fb-8c0a-4a3f4d834102	s3	1	1	2026-03-17 15:14:18.932+00	1	2026-03-17 15:14:18.932+00	1
\.


--
-- TOC entry 3517 (class 0 OID 67470)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, uid, name, email, password, avatar, role, status, created_at, updated_at, created_by, updated_by) FROM stdin;
1	019cfc46-94eb-723b-9f17-f1d52847d467	Administrador	admin@example.com	$2b$10$uQK/kHpoBm9iYd2HFHWxXeCnKw3yuYsvZ7xZKaUgUGQ4czRY8TjQu	\N	user	1	2026-03-17 14:50:10.027+00	2026-03-17 14:50:10.027+00	\N	\N
\.


--
-- TOC entry 3514 (class 0 OID 66118)
-- Dependencies: 215
-- Data for Name: migration; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.migration (sid, date) FROM stdin;
a3rpobf0	2026-03-17 12:50:27.355944+00
\.


--
-- TOC entry 3515 (class 0 OID 66126)
-- Dependencies: 216
-- Data for Name: revision; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.revision (hash, migration_sid, date, operation, relation, revision) FROM stdin;
d7e887a76e12c09a3678661b4990fb3a:e1cdcce75b4563f618e485454b6815dd8f64f3668e2d986a46fecfd238f7bbed	a3rpobf0	2026-03-17 12:50:27.385383+00	restore:data-"public"."users"	"public"."users"	\N
d7e887a76e12c09a3678661b4990fb3a:3b3d4ff29dd00e4918c50e12030a6d236f9aeaa1c9a3c7e55f7527911efd16fb	a3rpobf0	2026-03-17 12:50:27.38722+00	restore:data-"public"."projects"	"public"."projects"	\N
d7e887a76e12c09a3678661b4990fb3a:e3b14f40b30a0d9549ed21c976f3f0ff5f2b789cbc5843d7847efd371daf8b34	a3rpobf0	2026-03-17 12:50:27.388445+00	restore:data-"public"."collaborators"	"public"."collaborators"	\N
d7e887a76e12c09a3678661b4990fb3a:8e5632b2e35c0a24fd2ac367c1c6ea399134bf0a14e1559b4c03832d7120b871	a3rpobf0	2026-03-17 12:50:27.389748+00	restore:data-"public"."assets"	"public"."assets"	\N
d7e887a76e12c09a3678661b4990fb3a:391ca5ec35f269b55c907b0dfac43a4cbf2083344e9caecd7cf16f4e0ddef1b5	a3rpobf0	2026-03-17 12:50:27.391114+00	restore:data-"public"."invites"	"public"."invites"	\N
d7e887a76e12c09a3678661b4990fb3a:511485b6130b7483446f2e0cf53b3524c18192ac2f5377d86fa08320b9bfbcd1	a3rpobf0	2026-03-17 12:50:27.392863+00	restore:data-"public"."contributions"	"public"."contributions"	\N
\.


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 217
-- Name: temp_0_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_0_users_id_seq', 1, true);


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 219
-- Name: temp_1_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_1_projects_id_seq', 3, true);


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 221
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_2_collaborators_id_seq', 3, true);


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 223
-- Name: temp_3_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_3_assets_id_seq', 3, true);


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 225
-- Name: temp_4_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_4_invites_id_seq', 1, false);


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 227
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_5_contributions_id_seq', 1, false);


--
-- TOC entry 3346 (class 2606 OID 67538)
-- Name: assets pk_assets_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT pk_assets_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3340 (class 2606 OID 67536)
-- Name: collaborators pk_collaborators_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT pk_collaborators_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3358 (class 2606 OID 67542)
-- Name: contributions pk_contributions_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT pk_contributions_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3352 (class 2606 OID 67540)
-- Name: invites pk_invites_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT pk_invites_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3334 (class 2606 OID 67534)
-- Name: projects pk_projects_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT pk_projects_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 67532)
-- Name: users pk_users_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3348 (class 2606 OID 67558)
-- Name: assets uk_assets_project_id_path_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT uk_assets_project_id_path_by_prisma UNIQUE (project_id, path);


--
-- TOC entry 3350 (class 2606 OID 67556)
-- Name: assets uk_assets_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT uk_assets_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3342 (class 2606 OID 67552)
-- Name: collaborators uk_collaborators_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT uk_collaborators_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3344 (class 2606 OID 67554)
-- Name: collaborators uk_collaborators_user_id_project_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT uk_collaborators_user_id_project_id_by_prisma UNIQUE (user_id, project_id);


--
-- TOC entry 3360 (class 2606 OID 67564)
-- Name: contributions uk_contributions_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT uk_contributions_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3354 (class 2606 OID 67562)
-- Name: invites uk_invites_token_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT uk_invites_token_by_prisma UNIQUE (token);


--
-- TOC entry 3356 (class 2606 OID 67560)
-- Name: invites uk_invites_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT uk_invites_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3336 (class 2606 OID 67550)
-- Name: projects uk_projects_name_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uk_projects_name_by_prisma UNIQUE (name);


--
-- TOC entry 3338 (class 2606 OID 67548)
-- Name: projects uk_projects_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uk_projects_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3330 (class 2606 OID 67546)
-- Name: users uk_users_email_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_users_email_by_prisma UNIQUE (email);


--
-- TOC entry 3332 (class 2606 OID 67544)
-- Name: users uk_users_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_users_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3324 (class 2606 OID 66125)
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (sid);


--
-- TOC entry 3326 (class 2606 OID 66133)
-- Name: revision revision_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_pkey PRIMARY KEY (hash);


--
-- TOC entry 3365 (class 2606 OID 67585)
-- Name: assets AssetOwner; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "AssetOwner" FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- TOC entry 3366 (class 2606 OID 67580)
-- Name: assets AssetsProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "AssetsProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3363 (class 2606 OID 67570)
-- Name: collaborators CollaboratorProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT "CollaboratorProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3364 (class 2606 OID 67575)
-- Name: collaborators CollaboratorUser; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT "CollaboratorUser" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3370 (class 2606 OID 67610)
-- Name: contributions ContributionToProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT "ContributionToProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3371 (class 2606 OID 67605)
-- Name: contributions Contributor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT "Contributor" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3367 (class 2606 OID 67595)
-- Name: invites InviteCreator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteCreator" FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3368 (class 2606 OID 67590)
-- Name: invites InviteToProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteToProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3369 (class 2606 OID 67600)
-- Name: invites InviteUsedBy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteUsedBy" FOREIGN KEY (used_by) REFERENCES public.users(id);


--
-- TOC entry 3362 (class 2606 OID 67565)
-- Name: projects Owner; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "Owner" FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- TOC entry 3361 (class 2606 OID 66134)
-- Name: revision revision_migration_sid_fkey; Type: FK CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_migration_sid_fkey FOREIGN KEY (migration_sid) REFERENCES sys.migration(sid);


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2026-03-17 16:05:50 GMT

--
-- PostgreSQL database dump complete
--

\unrestrict XrnkwjDgUUdfjElXhdetyNng6HGLtHdhUrUtOeo5C9Kw3z1fIdydfGXnsxgDjSd

