--
-- PostgreSQL database dump
--

\restrict x8gx5ct0mFM9zMO5WPBteX4OvCT3SFOCXqzvbe3ezScLui440Ck1YtTeRIjk2kn

-- Dumped from database version 15.17
-- Dumped by pg_dump version 18.3 (Ubuntu 18.3-1.pgdg24.04+1)

-- Started on 2026-03-17 18:01:21 GMT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_migration_sid_fkey;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS "Owner";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteUsedBy";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteToProject";
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS "InviteCreator";
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS "Contributor";
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS "ContributionToProject";
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS "CollaboratorUser";
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS "CollaboratorProject";
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS "AssetsProject";
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS "AssetOwner";
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS "AssetChildren";
ALTER TABLE IF EXISTS ONLY sys.revision DROP CONSTRAINT IF EXISTS revision_pkey;
ALTER TABLE IF EXISTS ONLY sys.migration DROP CONSTRAINT IF EXISTS migration_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk_users_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS uk_users_email_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS uk_projects_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS uk_projects_name_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS uk_invites_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS uk_invites_token_by_prisma;
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS uk_contributions_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS uk_collaborators_user_id_project_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS uk_collaborators_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS uk_assets_uid_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS uk_assets_project_id_path_by_prisma;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS pk_users_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.projects DROP CONSTRAINT IF EXISTS pk_projects_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.invites DROP CONSTRAINT IF EXISTS pk_invites_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.contributions DROP CONSTRAINT IF EXISTS pk_contributions_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.collaborators DROP CONSTRAINT IF EXISTS pk_collaborators_id_by_prisma;
ALTER TABLE IF EXISTS ONLY public.assets DROP CONSTRAINT IF EXISTS pk_assets_id_by_prisma;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.projects ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.invites ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.contributions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.collaborators ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.assets ALTER COLUMN id DROP DEFAULT;
DROP TABLE IF EXISTS sys.revision;
DROP TABLE IF EXISTS sys.migration;
DROP SEQUENCE IF EXISTS public.temp_5_contributions_id_seq;
DROP SEQUENCE IF EXISTS public.temp_4_invites_id_seq;
DROP SEQUENCE IF EXISTS public.temp_3_assets_id_seq;
DROP SEQUENCE IF EXISTS public.temp_2_collaborators_id_seq;
DROP SEQUENCE IF EXISTS public.temp_1_projects_id_seq;
DROP SEQUENCE IF EXISTS public.temp_0_users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.projects;
DROP TABLE IF EXISTS public.invites;
DROP TABLE IF EXISTS public.contributions;
DROP TABLE IF EXISTS public.collaborators;
DROP TABLE IF EXISTS public.assets;
DROP FUNCTION IF EXISTS sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying);
DROP SCHEMA IF EXISTS sys;
-- *not* dropping schema, since initdb creates it
--
-- TOC entry 5 (class 2615 OID 65985)
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

-- *not* creating schema, since initdb creates it


--
-- TOC entry 3534 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS '';


--
-- TOC entry 6 (class 2615 OID 66117)
-- Name: sys; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA sys;


--
-- TOC entry 240 (class 1255 OID 66139)
-- Name: restore_serial(character varying, character varying, character varying, character varying, character varying, character varying, character varying); Type: FUNCTION; Schema: sys; Owner: -
--

CREATE FUNCTION sys.restore_serial(schema character varying, source character varying, shadow character varying, temp character varying, "from" character varying, "to" character varying, seq character varying) RETURNS TABLE(sequence character varying, counts bigint)
    LANGUAGE plpgsql
    AS $_$
        declare
        begin
   if exists(
     select *
       from pg_tables t
       where t.schemaname = schema
       and t.tablename = source
   ) then
       execute format( $statment$
       select max( %I ) from %I.%I
       $statment$, "from", schema, source )
       into counts;
   
       counts := coalesce( counts, 0 )+1;
       -- example district_id_seq
       sequence := coalesce( seq, format( '%I.%I', shadow, format( '%s_%s_seq', temp, "to" ) ) );
       perform setval( sequence::regclass, counts, false );
   end if;
   return next;
        end;
        $_$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 224 (class 1259 OID 115414)
-- Name: assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.assets (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    type character varying NOT NULL,
    name character varying NOT NULL,
    owner_id integer NOT NULL,
    project_id integer NOT NULL,
    parent_id integer,
    path character varying NOT NULL,
    configs json,
    "binary" bytea,
    text character varying,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 222 (class 1259 OID 115403)
-- Name: collaborators; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.collaborators (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    project_id integer NOT NULL,
    role character varying DEFAULT 'viewer'::character varying NOT NULL,
    start_at timestamp with time zone,
    end_at timestamp with time zone,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 228 (class 1259 OID 115434)
-- Name: contributions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contributions (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id integer NOT NULL,
    project_id integer,
    action character varying NOT NULL,
    details json,
    score integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 226 (class 1259 OID 115424)
-- Name: invites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invites (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    token character varying NOT NULL,
    project_id integer NOT NULL,
    created_by integer NOT NULL,
    role character varying DEFAULT 'viewer'::character varying NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    used_at timestamp with time zone,
    used_by integer
);


--
-- TOC entry 220 (class 1259 OID 115393)
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    owner_id integer NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by integer NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    updated_by integer NOT NULL
);


--
-- TOC entry 218 (class 1259 OID 115382)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id integer NOT NULL,
    uid uuid DEFAULT gen_random_uuid() NOT NULL,
    name character varying NOT NULL,
    email character varying NOT NULL,
    password character varying NOT NULL,
    avatar character varying,
    role character varying DEFAULT 'user'::character varying NOT NULL,
    status integer DEFAULT 1 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by integer,
    updated_by integer
);


--
-- TOC entry 217 (class 1259 OID 115381)
-- Name: temp_0_users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_0_users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3536 (class 0 OID 0)
-- Dependencies: 217
-- Name: temp_0_users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_0_users_id_seq OWNED BY public.users.id;


--
-- TOC entry 219 (class 1259 OID 115392)
-- Name: temp_1_projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_1_projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3537 (class 0 OID 0)
-- Dependencies: 219
-- Name: temp_1_projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_1_projects_id_seq OWNED BY public.projects.id;


--
-- TOC entry 221 (class 1259 OID 115402)
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_2_collaborators_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3538 (class 0 OID 0)
-- Dependencies: 221
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_2_collaborators_id_seq OWNED BY public.collaborators.id;


--
-- TOC entry 223 (class 1259 OID 115413)
-- Name: temp_3_assets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_3_assets_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3539 (class 0 OID 0)
-- Dependencies: 223
-- Name: temp_3_assets_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_3_assets_id_seq OWNED BY public.assets.id;


--
-- TOC entry 225 (class 1259 OID 115423)
-- Name: temp_4_invites_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_4_invites_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3540 (class 0 OID 0)
-- Dependencies: 225
-- Name: temp_4_invites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_4_invites_id_seq OWNED BY public.invites.id;


--
-- TOC entry 227 (class 1259 OID 115433)
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.temp_5_contributions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3541 (class 0 OID 0)
-- Dependencies: 227
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.temp_5_contributions_id_seq OWNED BY public.contributions.id;


--
-- TOC entry 215 (class 1259 OID 66118)
-- Name: migration; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.migration (
    sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- TOC entry 216 (class 1259 OID 66126)
-- Name: revision; Type: TABLE; Schema: sys; Owner: -
--

CREATE TABLE sys.revision (
    hash character varying NOT NULL,
    migration_sid character varying NOT NULL,
    date timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    operation character varying NOT NULL,
    relation character varying NOT NULL,
    revision character varying
);


--
-- TOC entry 3311 (class 2604 OID 115417)
-- Name: assets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets ALTER COLUMN id SET DEFAULT nextval('public.temp_3_assets_id_seq'::regclass);


--
-- TOC entry 3306 (class 2604 OID 115406)
-- Name: collaborators id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators ALTER COLUMN id SET DEFAULT nextval('public.temp_2_collaborators_id_seq'::regclass);


--
-- TOC entry 3319 (class 2604 OID 115437)
-- Name: contributions id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions ALTER COLUMN id SET DEFAULT nextval('public.temp_5_contributions_id_seq'::regclass);


--
-- TOC entry 3315 (class 2604 OID 115427)
-- Name: invites id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites ALTER COLUMN id SET DEFAULT nextval('public.temp_4_invites_id_seq'::regclass);


--
-- TOC entry 3302 (class 2604 OID 115396)
-- Name: projects id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN id SET DEFAULT nextval('public.temp_1_projects_id_seq'::regclass);


--
-- TOC entry 3297 (class 2604 OID 115385)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.temp_0_users_id_seq'::regclass);


--
-- TOC entry 3524 (class 0 OID 115414)
-- Dependencies: 224
-- Data for Name: assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.assets (id, uid, type, name, owner_id, project_id, parent_id, path, configs, "binary", text, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5d-e811-71cc-ad8a-dd777874f358	schema:raw	main.prisma	1	1	\N	prisma/schema.prisma	{}	\N	model User {\n  id        Int      @id @default(autoincrement())\n  email     String   @unique\n  password  String\n  name      String?\n  role      Role     @default(USER)\n  profile   Profile?\n  createdAt DateTime @default(now())\n}\n\nmodel Profile {\n  id     Int    @id @default(autoincrement())\n  bio    String\n  user   User   @relation(fields: [userId], references: [id])\n  userId Int    @unique\n}\n\nenum Role {\n  USER\n  ADMIN\n}	1	2026-03-17 15:15:38.641+00	1	2026-03-17 15:16:20.502+00	1
2	019cfc5d-e8a9-711b-9fdc-75a2fa31045b	project:config	config	1	1	\N	.studio/config.json	{"databaseConfig":{"url":"","type":"postgresql","infraMode":"docker","useFields":false},"activeEnvironmentId":null,"activeFlowId":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","openFlowIds":["482e99b0-4d7d-4d4e-8f82-58c1cfae6750"],"useDirectSchema":true,"folders":[],"environments":[]}	\N	\N	1	2026-03-17 15:15:38.793+00	1	2026-03-17 16:47:48.023+00	1
16	019cfcd4-facb-769e-ae51-9ec8da05716a	project:flow	Novo Fluxo	1	1	\N	flows/cb1ba568-a123-4c0c-ae4f-8b7e00090436.flow	{"id":"cb1ba568-a123-4c0c-ae4f-8b7e00090436","name":"Novo Fluxo","folderId":null,"nodes":[],"edges":[],"createdAt":1773768342211}	\N	\N	1	2026-03-17 17:25:42.219+00	1	2026-03-17 17:25:42.219+00	1
23	019cfcde-6617-7599-a8ac-f017757ad3c2	flow:edge	Edge edge-1773768959503	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/edges/edge-1773768959503.edge	{"source":"model-1773768842045","sourceHandle":"out-bottom","target":"model-1773768890166","targetHandle":"in-top","id":"edge-1773768959503","type":"default","animated":true,"markerEnd":{"type":"arrowclosed"},"data":{"operationType":"Get","linkType":"natural"}}	\N	\N	1	2026-03-17 17:35:59.511+00	1	2026-03-17 17:35:59.511+00	1
21	019cfcdd-661d-74ca-b092-382c3201efc5	flow:node	Node model-1773768893974	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/nodes/model-1773768893974.node	{"id":"model-1773768893974","type":"model","position":{"x":-1337.463473919075,"y":-492.6738506774222},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1337.463473919075,"y":-492.6738506774222},"dragging":false}	\N	\N	1	2026-03-17 17:34:53.981+00	1	2026-03-17 17:57:59.373+00	1
19	019cfcdc-ec76-75da-b18e-3ccc0c1bdc0c	flow:edge	Edge edge-1773768862829	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/edges/edge-1773768862829.edge	{"source":"op-1773768840998","sourceHandle":"right","target":"model-1773768842045","targetHandle":"in-left","id":"edge-1773768862829","type":"default","animated":true,"markerEnd":{"type":"arrowclosed"},"data":{"operationType":"Get","linkType":"natural"}}	\N	\N	1	2026-03-17 17:34:22.837+00	1	2026-03-17 17:34:22.837+00	1
22	019cfcde-53fa-741b-8d31-756628b77bb4	flow:edge	Edge edge-1773768954855	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/edges/edge-1773768954855.edge	{"source":"model-1773768842045","sourceHandle":"out-bottom","target":"model-1773768893974","targetHandle":"in-left","id":"edge-1773768954855","type":"default","animated":true,"markerEnd":{"type":"arrowclosed"},"data":{"operationType":"Find","linkType":"natural"},"assetUid":"019cfcde-53fa-741b-8d31-756628b77bb4","selected":true}	\N	\N	1	2026-03-17 17:35:54.874+00	1	2026-03-17 17:54:59.629+00	1
18	019cfcdc-9b53-7728-a2e2-374ab2967015	flow:node	Node model-1773768842045	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/nodes/model-1773768842045.node	{"id":"model-1773768842045","type":"model","position":{"x":-1021.3830889784624,"y":-252.8465497712114},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1021.3830889784624,"y":-252.8465497712114},"dragging":false}	\N	\N	1	2026-03-17 17:34:02.066+00	1	2026-03-17 17:57:03.62+00	1
17	019cfcdc-972d-7222-b0ca-a046fe152dee	flow:node	Node op-1773768840998	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/nodes/op-1773768840998.node	{"id":"op-1773768840998","type":"operation","position":{"x":-1917.9016720437728,"y":-265.34650193968315},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1917.9016720437728,"y":-265.34650193968315},"dragging":true}	\N	\N	1	2026-03-17 17:34:01.005+00	1	2026-03-17 17:57:38.599+00	1
20	019cfcdd-5741-720d-ab62-22bcc782765f	flow:node	Node model-1773768890166	1	1	16	flows/019cfcd4-facb-769e-ae51-9ec8da05716a/nodes/model-1773768890166.node	{"id":"model-1773768890166","type":"model","position":{"x":-1218.3342473024438,"y":90.73558294890357},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1218.3342473024438,"y":90.73558294890357},"dragging":false}	\N	\N	1	2026-03-17 17:34:50.176+00	1	2026-03-17 17:57:51.411+00	1
\.


--
-- TOC entry 3522 (class 0 OID 115403)
-- Dependencies: 222
-- Data for Name: collaborators; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.collaborators (id, uid, user_id, project_id, role, start_at, end_at, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5a-e9de-75db-abc9-77ae3f9a6d23	1	1	owner	\N	\N	1	2026-03-17 15:12:22.494+00	1	2026-03-17 15:12:22.494+00	1
2	019cfc5c-2db7-7460-a6d9-39f2552bd731	1	2	owner	\N	\N	1	2026-03-17 15:13:45.399+00	1	2026-03-17 15:13:45.399+00	1
3	019cfc5c-b0b7-77fb-92ea-4f74cac42be4	1	3	owner	\N	\N	1	2026-03-17 15:14:18.935+00	1	2026-03-17 15:14:18.935+00	1
\.


--
-- TOC entry 3528 (class 0 OID 115434)
-- Dependencies: 228
-- Data for Name: contributions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contributions (id, uid, user_id, project_id, action, details, score, created_at) FROM stdin;
1	019cfcb2-46c2-72d9-965b-1531cabeca97	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-192.46469916276374,"y":-31.191415368114008},"selected":false,"positionAbsolute":{"x":-192.46469916276374,"y":-31.191415368114008}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":160.45922214453435,"y":-61.05513026987195},"selected":true,"positionAbsolute":{"x":160.45922214453435,"y":-61.05513026987195}}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:47:47.906+00
2	019cfcb2-473f-77da-8991-ce102fa543c2	1	1	asset_updated	{"assetUid":"019cfc5d-e8a9-711b-9fdc-75a2fa31045b","changes":{"configs":{"databaseConfig":{"url":"","type":"postgresql","infraMode":"docker","useFields":false},"activeEnvironmentId":null,"activeFlowId":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","openFlowIds":["482e99b0-4d7d-4d4e-8f82-58c1cfae6750"],"useDirectSchema":true,"folders":[],"environments":[]}}}	1	2026-03-17 16:47:48.031+00
3	019cfcb2-908d-71ec-aa7e-36bcf212581f	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-192.46469916276374,"y":-31.191415368114008},"selected":false,"positionAbsolute":{"x":-192.46469916276374,"y":-31.191415368114008}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":160.45922214453435,"y":-61.05513026987195},"selected":false,"positionAbsolute":{"x":160.45922214453435,"y":-61.05513026987195}},{"id":"model-1773766082924","type":"model","position":{"x":400,"y":100},"data":{"id":"model-1773766082924","modelName":"","outputs":{},"filters":{}},"width":256,"height":200}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:48:06.797+00
4	019cfcb3-07c2-706b-92d1-f1702d807527	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-192.46469916276374,"y":-31.191415368114008},"selected":false,"positionAbsolute":{"x":-192.46469916276374,"y":-31.191415368114008}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":160.45922214453435,"y":-61.05513026987195},"selected":false,"positionAbsolute":{"x":160.45922214453435,"y":-61.05513026987195}},{"id":"model-1773766082924","type":"model","position":{"x":31.787672083492907,"y":164.85558048529384},"data":{"id":"model-1773766082924","modelName":"","outputs":{},"filters":{}},"width":256,"height":200,"selected":true,"positionAbsolute":{"x":31.787672083492907,"y":164.85558048529384},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:48:37.314+00
5	019cfcb3-45ea-7340-bfa9-2e49de16a7f1	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-247.55707398360477,"y":-65.36263519369894},"selected":true,"positionAbsolute":{"x":-247.55707398360477,"y":-65.36263519369894}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":67.70876833223235,"y":-87.55525993052964},"selected":false,"positionAbsolute":{"x":67.70876833223235,"y":-87.55525993052964}},{"id":"model-1773766082924","type":"model","position":{"x":31.787672083492907,"y":164.85558048529384},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":31.787672083492907,"y":164.85558048529384},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:48:53.226+00
37	019cfcdd-6ae5-70dc-bafd-aa8d43130147	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":197.5,"y":-205.5},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":true,"positionAbsolute":{"x":197.5,"y":-205.5},"dragging":true}}}	1	2026-03-17 17:34:55.205+00
38	019cfcdd-8bb6-720f-bf56-a32d780a0329	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":163.9826996197719,"y":31.638973384030407},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":163.9826996197719,"y":31.638973384030407},"dragging":true}}}	1	2026-03-17 17:35:03.606+00
6	019cfcb3-6e15-72b8-9846-181b8bca142a	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-247.55707398360477,"y":-65.36263519369894},"selected":false,"positionAbsolute":{"x":-247.55707398360477,"y":-65.36263519369894}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":67.70876833223235,"y":-87.55525993052964},"selected":false,"positionAbsolute":{"x":67.70876833223235,"y":-87.55525993052964}},{"id":"model-1773766082924","type":"model","position":{"x":122.44601039626929,"y":140.44756632416176},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":true,"positionAbsolute":{"x":122.44601039626929,"y":140.44756632416176},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:49:03.509+00
7	019cfcb3-960a-72ac-85a8-8144a4eb7bad	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-247.55707398360477,"y":-65.36263519369894},"selected":false,"positionAbsolute":{"x":-247.55707398360477,"y":-65.36263519369894}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":69.10351199858275,"y":-155.8976995816995},"selected":true,"positionAbsolute":{"x":69.10351199858275,"y":-155.8976995816995}},{"id":"model-1773766082924","type":"model","position":{"x":122.44601039626929,"y":140.44756632416176},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":122.44601039626929,"y":140.44756632416176},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 16:49:13.738+00
8	019cfcbf-8363-742f-a298-0a6a3e471589	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-363.3198634921889,"y":-56.2968745695327},"selected":true,"positionAbsolute":{"x":-363.3198634921889,"y":-56.2968745695327}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":-20.159361839361708,"y":-47.10857209170472},"selected":false,"positionAbsolute":{"x":-20.159361839361708,"y":-47.10857209170472}},{"id":"model-1773766082924","type":"model","position":{"x":279.353405814531,"y":88.14510118474118},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":279.353405814531,"y":88.14510118474118},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 17:02:15.395+00
9	019cfcbf-9b7a-75ea-a990-d71e6409e37d	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-363.3198634921889,"y":-56.2968745695327},"selected":false,"positionAbsolute":{"x":-363.3198634921889,"y":-56.2968745695327}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":-20.159361839361708,"y":-47.10857209170472},"selected":false,"positionAbsolute":{"x":-20.159361839361708,"y":-47.10857209170472}},{"id":"model-1773766082924","type":"model","position":{"x":271.5722290691742,"y":212.64392911044948},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":271.5722290691742,"y":212.64392911044948},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 17:02:21.562+00
10	019cfcbf-a98c-738a-9b2c-63a6e8faa267	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-bottom","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766128794","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]},"selected":true}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-363.3198634921889,"y":-56.2968745695327},"selected":false,"positionAbsolute":{"x":-363.3198634921889,"y":-56.2968745695327}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":-20.159361839361708,"y":-47.10857209170472},"selected":false,"positionAbsolute":{"x":-20.159361839361708,"y":-47.10857209170472}},{"id":"model-1773766082924","type":"model","position":{"x":271.5722290691742,"y":212.64392911044948},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":271.5722290691742,"y":212.64392911044948},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 17:02:25.164+00
11	019cfcbf-b2a5-7309-a728-e66108ef4cd3	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-363.3198634921889,"y":-56.2968745695327},"selected":false,"positionAbsolute":{"x":-363.3198634921889,"y":-56.2968745695327}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":-20.159361839361708,"y":-47.10857209170472},"selected":false,"positionAbsolute":{"x":-20.159361839361708,"y":-47.10857209170472}},{"id":"model-1773766082924","type":"model","position":{"x":271.5722290691742,"y":212.64392911044948},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":271.5722290691742,"y":212.64392911044948},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 17:02:27.493+00
12	019cfcbf-c734-73dd-9e27-584d655d1c93	1	1	asset_updated	{"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678","changes":{"name":"Novo Fluxo 1","configs":{"id":"482e99b0-4d7d-4d4e-8f82-58c1cfae6750","name":"Novo Fluxo 1","edges":[{"id":"edge-1773760572373","data":{"sourceId":"op-1773760558542","targetId":"model-1773760559926","conditions":[],"operationType":"Get"},"type":"relation","source":"op-1773760558542","target":"model-1773760559926","animated":true,"markerEnd":{"type":"arrow","color":"#3b82f6","width":18,"height":18},"sourceHandle":"right","targetHandle":"in-left"},{"source":"model-1773760559926","sourceHandle":"out-right","target":"model-1773766082924","targetHandle":"in-top","id":"edge-1773766951164","type":"relation","animated":true,"markerEnd":{"type":"arrow","width":18,"height":18,"color":"#3b82f6"},"data":{"sourceId":"model-1773760559926","targetId":"model-1773766082924","operationType":"Get","conditions":[]}}],"nodes":[{"id":"op-1773760558542","data":{"id":"op-1773760558542","method":"Sets","versions":{"rest":true,"graphql":true}},"type":"operation","width":256,"height":173,"dragging":false,"position":{"x":-363.3198634921889,"y":-56.2968745695327},"selected":false,"positionAbsolute":{"x":-363.3198634921889,"y":-56.2968745695327}},{"id":"model-1773760559926","data":{"id":"model-1773760559926","filters":{},"outputs":{},"modelName":"User"},"type":"model","width":256,"height":214,"dragging":false,"position":{"x":-20.159361839361708,"y":-47.10857209170472},"selected":false,"positionAbsolute":{"x":-20.159361839361708,"y":-47.10857209170472}},{"id":"model-1773766082924","type":"model","position":{"x":271.5722290691742,"y":212.64392911044948},"data":{"id":"model-1773766082924","modelName":"User","outputs":{},"filters":{}},"width":256,"height":214,"selected":false,"positionAbsolute":{"x":271.5722290691742,"y":212.64392911044948},"dragging":false}],"folderId":null,"createdAt":1773760557006,"assetUid":"019cfc5e-41df-74aa-9d76-c1eb45879678"}}}	1	2026-03-17 17:02:32.756+00
13	019cfccf-a8a5-747c-862c-50b45b4f97d1	1	1	asset_created	{"assetUid":"019cfccf-a898-77a9-81c5-788d2561168e"}	1	2026-03-17 17:19:53.508+00
14	019cfccf-bdd5-7237-b23a-8f15f37715a0	1	1	asset_created	{"assetUid":"019cfccf-bdcf-73d9-96b5-0dcdac79b13c","parentUid":"019cfccf-a898-77a9-81c5-788d2561168e"}	1	2026-03-17 17:19:58.933+00
15	019cfccf-c2f8-744e-9902-bb7cc8994eaa	1	1	asset_created	{"assetUid":"019cfccf-c2f2-7694-ba49-94ef10a05710","parentUid":"019cfccf-a898-77a9-81c5-788d2561168e"}	1	2026-03-17 17:20:00.248+00
16	019cfccf-c946-7277-9e3f-cde23b643c53	1	1	asset_created	{"assetUid":"019cfccf-c940-75d7-bb17-f32bc3ced37f","parentUid":"019cfccf-a898-77a9-81c5-788d2561168e"}	1	2026-03-17 17:20:01.862+00
17	019cfccf-d76b-7010-afb8-9ce3ccd65378	1	1	asset_created	{"assetUid":"019cfccf-d762-73a3-8847-cd3c8fb6d108","parentUid":"019cfccf-a898-77a9-81c5-788d2561168e"}	1	2026-03-17 17:20:05.483+00
18	019cfcd3-5f85-70fc-9dc5-76b695b0e83b	1	1	asset_created	{"assetUid":"019cfcd3-5f76-70f8-94ab-0727f13c0d80"}	1	2026-03-17 17:23:56.932+00
19	019cfcd3-743c-734f-8718-bf7a94faefd2	1	1	asset_created	{"assetUid":"019cfcd3-7432-7516-beb2-07526ac78ced"}	1	2026-03-17 17:24:02.236+00
20	019cfcd3-7493-72df-8958-2ee9f254f999	1	1	asset_created	{"assetUid":"019cfcd3-748a-7071-b53a-0bdae14ff1fb"}	1	2026-03-17 17:24:02.323+00
21	019cfcd3-8fd7-7278-abda-a82f79506797	1	1	asset_created	{"assetUid":"019cfcd3-8fba-77f3-a5f9-c4960f15dc7c"}	1	2026-03-17 17:24:09.303+00
22	019cfcd3-8fec-7358-a790-6fee7f93bda1	1	1	asset_created	{"assetUid":"019cfcd3-8fe6-72f8-a893-81e3b8f0853c"}	1	2026-03-17 17:24:09.324+00
23	019cfcd4-b57a-7349-aa48-553a436947bc	1	1	asset_created	{"assetUid":"019cfcd4-b569-743b-8061-f9513874e7f5"}	1	2026-03-17 17:25:24.474+00
24	019cfcd4-b5af-7180-ab6d-2d14a9f66044	1	1	asset_created	{"assetUid":"019cfcd4-b5a7-70ff-90ac-548da062af79"}	1	2026-03-17 17:25:24.527+00
25	019cfcd4-fad6-77fe-8a49-db526bf71435	1	1	asset_created	{"assetUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:25:42.23+00
26	019cfcdc-9733-718e-b8af-d094339be422	1	1	asset_created	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:34:01.011+00
27	019cfcdc-9b58-774f-897a-c72ffee01e63	1	1	asset_created	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:34:02.072+00
28	019cfcdc-e4dd-75a0-8fe5-c50be5a1b0e2	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":30,"y":51.5},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":30,"y":51.5},"dragging":true}}}	1	2026-03-17 17:34:20.893+00
29	019cfcdc-e84b-70c0-9d79-aa1e76768556	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":375.5,"y":72},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":true,"positionAbsolute":{"x":375.5,"y":72},"dragging":true}}}	1	2026-03-17 17:34:21.771+00
30	019cfcdc-ec7c-7549-af22-b8f2288d647a	1	1	asset_created	{"assetUid":"019cfcdc-ec76-75da-b18e-3ccc0c1bdc0c","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:34:22.844+00
31	019cfcdd-3fad-7137-bf03-f3b0f4a0d474	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":30,"y":51.5},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":30,"y":51.5},"dragging":false}}}	1	2026-03-17 17:34:44.141+00
32	019cfcdd-47c9-735b-8cff-dc3a84148c40	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":329.5,"y":14.5},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":true,"positionAbsolute":{"x":329.5,"y":14.5},"dragging":true}}}	1	2026-03-17 17:34:46.217+00
33	019cfcdd-4b3d-7368-bc38-7b7aa87e3d5a	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-15.5,"y":107.5},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-15.5,"y":107.5},"dragging":true}}}	1	2026-03-17 17:34:47.101+00
34	019cfcdd-5746-741d-bf57-7fa8f6b70ff6	1	1	asset_created	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:34:50.182+00
35	019cfcdd-6247-765c-ab91-d057b45fecdd	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-163.4999999999999,"y":-58.5},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-163.4999999999999,"y":-58.5},"dragging":true}}}	1	2026-03-17 17:34:52.999+00
36	019cfcdd-6620-762a-8480-6ff9af55671c	1	1	asset_created	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:34:53.984+00
39	019cfcde-43f0-72c8-ac24-85ea9ec46df4	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-275.5557034220531,"y":-158.5749049429658},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-275.5557034220531,"y":-158.5749049429658},"dragging":true}}}	1	2026-03-17 17:35:50.768+00
40	019cfcde-48e7-70db-8a87-58bbb0854041	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":108.70114068441069,"y":-224.52832699619773},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":true,"positionAbsolute":{"x":108.70114068441069,"y":-224.52832699619773},"dragging":true}}}	1	2026-03-17 17:35:52.039+00
41	019cfcde-4cc7-72d9-95c6-43d276114c61	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":395.84638783269975,"y":-88.16901140684412},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":395.84638783269975,"y":-88.16901140684412},"dragging":true}}}	1	2026-03-17 17:35:53.031+00
42	019cfcde-5402-74e2-8c62-de5a607eb659	1	1	asset_created	{"assetUid":"019cfcde-53fa-741b-8d31-756628b77bb4","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:35:54.882+00
43	019cfcde-549c-719d-a00f-3aacf2f671a2	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":395.84638783269975,"y":-88.87376425855516},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":395.84638783269975,"y":-88.87376425855516},"dragging":false}}}	1	2026-03-17 17:35:55.036+00
44	019cfcde-5ad1-7081-b46c-e59fca3a27f6	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-98.89011406844105,"y":94.36197718631178},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-98.89011406844105,"y":94.36197718631178},"dragging":true}}}	1	2026-03-17 17:35:56.624+00
45	019cfcde-6099-76ed-9671-8260db457609	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":108.70114068441069,"y":-224.52832699619773},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":true,"positionAbsolute":{"x":108.70114068441069,"y":-224.52832699619773},"dragging":false}}}	1	2026-03-17 17:35:58.105+00
46	019cfcde-661e-727c-bce5-779b04242160	1	1	asset_created	{"assetUid":"019cfcde-6617-7599-a8ac-f017757ad3c2","parentUid":"019cfcd4-facb-769e-ae51-9ec8da05716a"}	1	2026-03-17 17:35:59.518+00
47	019cfcde-69f1-75ef-ab0e-e61b8d816f9f	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-38.986121673003765,"y":95.0667300380228},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-38.986121673003765,"y":95.0667300380228},"dragging":true}}}	1	2026-03-17 17:36:00.497+00
48	019cfcde-c98c-76aa-9ab2-51be8c88a251	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":295.48958174904953,"y":26.000950570342184},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":295.48958174904953,"y":26.000950570342184},"dragging":true}}}	1	2026-03-17 17:36:24.972+00
49	019cfcdf-3b3f-7309-828a-159a5d7cadd8	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-36.16711026615968,"y":88.72395437262358},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-36.16711026615968,"y":88.72395437262358},"dragging":true}}}	1	2026-03-17 17:36:54.079+00
50	019cfcdf-5126-7351-b39d-a1d4dbc4dffe	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-151.746577946768,"y":49.25779467680607},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-151.746577946768,"y":49.25779467680607},"dragging":true}}}	1	2026-03-17 17:36:59.686+00
51	019cfcdf-5f3f-7148-be2a-59b8f329eb62	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-151.746577946768,"y":49.25779467680607},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":false,"positionAbsolute":{"x":-151.746577946768,"y":49.25779467680607},"dragging":false}}}	1	2026-03-17 17:37:03.295+00
52	019cfcdf-6f85-76f9-bcb9-fe07e8dd15a4	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-275.5557034220531,"y":-158.5749049429658},"data":{"method":"CreateMany","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-275.5557034220531,"y":-158.5749049429658},"dragging":false}}}	1	2026-03-17 17:37:07.461+00
53	019cfce0-bd45-733d-a7b5-6c97398b2bc3	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-275.5557034220531,"y":-158.5749049429658},"data":{"method":"Find","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-275.5557034220531,"y":-158.5749049429658},"dragging":true}}}	1	2026-03-17 17:38:32.901+00
54	019cfce0-caa5-7422-8080-c7d79e132126	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":108.70114068441069,"y":-224.52832699619773},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":200,"selected":false,"positionAbsolute":{"x":108.70114068441069,"y":-224.52832699619773},"dragging":false}}}	1	2026-03-17 17:38:36.325+00
55	019cfce0-dbe8-721d-8daf-b50cd81d9e42	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-296.5634123186205,"y":-173.78738379910075},"data":{"method":"Find","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-296.5634123186205,"y":-173.78738379910075},"dragging":true}}}	1	2026-03-17 17:38:40.744+00
56	019cfce0-e2dc-7365-9d1a-822bf3e51c84	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":184.79738948236513,"y":-345.7186491559029},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":184.79738948236513,"y":-345.7186491559029},"dragging":true}}}	1	2026-03-17 17:38:42.524+00
57	019cfce0-e64a-70c2-b650-5e2d446231e4	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":566.0540219195542,"y":-164.23967142454387},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":566.0540219195542,"y":-164.23967142454387},"dragging":true}}}	1	2026-03-17 17:38:43.402+00
58	019cfce0-ed01-7130-8ed2-a31172531570	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-291.50876040112735,"y":143.27020886058196},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-291.50876040112735,"y":143.27020886058196},"dragging":true}}}	1	2026-03-17 17:38:45.121+00
59	019cfce0-f09a-719e-b86a-9c72f058afba	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Find","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:38:46.042+00
60	019cfce0-f34c-7245-8fe4-ef941822dc76	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-283.053621645799,"y":-96.29205587371897},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-283.053621645799,"y":-96.29205587371897},"dragging":true}}}	1	2026-03-17 17:38:46.732+00
61	019cfce0-f710-756d-964f-720b7021574e	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":111.79718613035027,"y":181.0273073838602},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":111.79718613035027,"y":181.0273073838602},"dragging":true}}}	1	2026-03-17 17:38:47.696+00
62	019cfce0-faa4-73b9-bf13-30a9682afe8b	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":111.79718613035027,"y":182.4364971764149},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":200,"selected":true,"positionAbsolute":{"x":111.79718613035027,"y":182.4364971764149},"dragging":false}}}	1	2026-03-17 17:38:48.612+00
63	019cfce1-0387-7165-ab20-c49f8e9fce1e	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:38:50.887+00
86	019cfce3-6917-7478-aa31-00918e5e6559	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:41:27.959+00
87	019cfce3-c6ed-76d1-8ae3-84079d801344	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"CreateMany","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:41:51.981+00
88	019cfce3-d742-719f-aa5e-7a79525c8f96	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":false,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:41:56.162+00
89	019cfce4-16fd-751e-9a7b-9a1a4b00f42c	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Find","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:42:12.477+00
90	019cfce4-5287-74cb-9277-34919b1489f0	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:42:27.719+00
91	019cfce5-6ba3-7638-a73e-3e54d6785c62	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:43:39.683+00
92	019cfce5-97ce-709d-8a77-d2b8d7c39bb2	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":111.79718613035027,"y":182.4364971764149},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":111.79718613035027,"y":182.4364971764149},"dragging":false}}}	1	2026-03-17 17:43:50.99+00
93	019cfce6-0204-7045-9494-73f9a5f15558	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:44:18.18+00
94	019cfce6-162c-756b-9936-0d69a3539103	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Find","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:44:23.34+00
95	019cfce7-c639-7408-b0ab-afb8e0d93121	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:46:13.945+00
96	019cfce7-d675-721c-b3a4-e83ec049a57b	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:46:18.101+00
97	019cfce9-7d7a-70ef-b154-d34bf45f9fd7	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":false,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:48:06.394+00
98	019cfce9-920a-7664-bff8-dcb20b5d5003	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:48:11.658+00
99	019cfce9-9f28-7668-8dff-3c92c619f938	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"UpdateMany","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:48:15.016+00
100	019cfce9-e34c-766f-bbc2-c54298726ebb	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":111.79718613035027,"y":182.4364971764149},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":111.79718613035027,"y":182.4364971764149},"dragging":false}}}	1	2026-03-17 17:48:32.46+00
101	019cfcee-58b6-76aa-86be-a9cddae37ad6	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-636.178152324306,"y":-113.19222271924818},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":false,"positionAbsolute":{"x":-636.178152324306,"y":-113.19222271924818},"dragging":true}}}	1	2026-03-17 17:53:24.662+00
102	019cfcee-6840-70ca-83da-74a2895bb879	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-218.23089118828227,"y":-173.79749446422812},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":false,"positionAbsolute":{"x":-218.23089118828227,"y":-173.79749446422812},"dragging":true}}}	1	2026-03-17 17:53:28.64+00
103	019cfcee-7305-7307-9798-89865e3c4175	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-762.178152324306,"y":-223.1922227192482},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-762.178152324306,"y":-223.1922227192482},"dragging":true}}}	1	2026-03-17 17:53:31.397+00
104	019cfcee-7a65-742e-8f7b-27c3ccd47935	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-479.3718031589232,"y":2.009969893959294},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-479.3718031589232,"y":2.009969893959294},"dragging":true}}}	1	2026-03-17 17:53:33.285+00
105	019cfcee-8089-73e5-9fc1-9f1b20e4bd2d	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-480.3999169855793,"y":2.009969893959294},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-480.3999169855793,"y":2.009969893959294},"dragging":false}}}	1	2026-03-17 17:53:34.857+00
106	019cfcee-8d86-76ff-b6db-1d1b1da732c0	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-727.1436964210003,"y":240.0108714691546},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-727.1436964210003,"y":240.0108714691546},"dragging":true}}}	1	2026-03-17 17:53:38.182+00
107	019cfcee-95f5-770d-b55f-7f7afe1c2466	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-653.1195009017636,"y":271.8824000954927},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-653.1195009017636,"y":271.8824000954927},"dragging":true}}}	1	2026-03-17 17:53:40.341+00
108	019cfcee-9b86-75a3-80f9-13d88b4e9b5c	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-652.0913870751075,"y":271.8824000954927},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-652.0913870751075,"y":271.8824000954927},"dragging":false}}}	1	2026-03-17 17:53:41.766+00
109	019cfcee-aa1d-71c4-b75b-c5d14af5936d	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-827.1150538336029,"y":-97.87539524516643},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-827.1150538336029,"y":-97.87539524516643},"dragging":true}}}	1	2026-03-17 17:53:45.501+00
110	019cfcee-aa42-717e-b33b-7d6362e8fb8b	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-717.0282885844044,"y":397.1992275695745},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-717.0282885844044,"y":397.1992275695745},"dragging":true}}}	1	2026-03-17 17:53:45.538+00
111	019cfcee-aa44-7714-a9b1-d0aa7dcf44f0	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-545.3368184948762,"y":127.32679736804107},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-545.3368184948762,"y":127.32679736804107},"dragging":true}}}	1	2026-03-17 17:53:45.54+00
112	019cfcee-aa45-773a-b87b-244c29738072	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":501.11712041025726,"y":-38.922843950462095},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":501.11712041025726,"y":-38.922843950462095},"dragging":true}}}	1	2026-03-17 17:53:45.541+00
113	019cfcee-b1aa-71e9-8aac-1afbf12920e1	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-453.05806371850684,"y":-87.99029711015393},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-453.05806371850684,"y":-87.99029711015393},"dragging":true}}}	1	2026-03-17 17:53:47.434+00
114	019cfcef-7dcc-7429-86f1-fd91be6fdc61	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-909.14061363482,"y":-141.16666291803102},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-909.14061363482,"y":-141.16666291803102},"dragging":true}}}	1	2026-03-17 17:54:39.692+00
115	019cfcef-84fc-77ae-8021-a0aabbabaf4a	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-920.5330524961003,"y":-34.0777376219975},"data":{"method":"Create","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-920.5330524961003,"y":-34.0777376219975},"dragging":true}}}	1	2026-03-17 17:54:41.532+00
116	019cfcef-8aef-766c-8398-559d4fdacdef	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-920.5330524961003,"y":-34.0777376219975},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-920.5330524961003,"y":-34.0777376219975},"dragging":false}}}	1	2026-03-17 17:54:43.055+00
117	019cfcef-9223-761c-a3f8-dd3c0edffd21	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-530.526647975212,"y":-73.18012659048973},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-530.526647975212,"y":-73.18012659048973},"dragging":true}}}	1	2026-03-17 17:54:44.899+00
118	019cfcef-9805-74cd-bc9c-b4a314194ce3	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-530.526647975212,"y":-73.18012659048973},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-530.526647975212,"y":-73.18012659048973},"dragging":false}}}	1	2026-03-17 17:54:46.405+00
119	019cfcef-9cc0-77ff-a47c-154b8b5f3cc4	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-960.4065885105807,"y":-59.14110311681385},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-960.4065885105807,"y":-59.14110311681385},"dragging":true}}}	1	2026-03-17 17:54:47.616+00
120	019cfcef-9ff6-76cc-99bc-171b289c86b1	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-594.3243055983809,"y":-100.52197985756214},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-594.3243055983809,"y":-100.52197985756214},"dragging":true}}}	1	2026-03-17 17:54:48.438+00
121	019cfcef-a66a-7256-a614-1a7e052b5252	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-603.1038999716029,"y":211.5024741307078},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-603.1038999716029,"y":211.5024741307078},"dragging":true}}}	1	2026-03-17 17:54:50.09+00
122	019cfcef-ab01-77b8-83d0-e5611fd4d70c	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-603.1038999716029,"y":211.5024741307078},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-603.1038999716029,"y":211.5024741307078},"dragging":false}}}	1	2026-03-17 17:54:51.265+00
123	019cfcef-b8a9-71a6-ac02-db1b14ac6d7d	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-54.83389602021464,"y":-111.83445266265511},"data":{"modelName":"","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-54.83389602021464,"y":-111.83445266265511},"dragging":true}}}	1	2026-03-17 17:54:54.761+00
124	019cfcef-be0d-7598-9093-0f5b88f87fc4	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-54.83389602021464,"y":-111.83445266265511},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":200,"selected":true,"positionAbsolute":{"x":-54.83389602021464,"y":-111.83445266265511},"dragging":false}}}	1	2026-03-17 17:54:56.141+00
125	019cfcef-cbb2-711b-941d-d5a294fa0cc6	1	1	asset_updated	{"assetUid":"019cfcde-53fa-741b-8d31-756628b77bb4","changes":{"configs":{"source":"model-1773768842045","sourceHandle":"out-bottom","target":"model-1773768893974","targetHandle":"in-left","id":"edge-1773768954855","type":"default","animated":true,"markerEnd":{"type":"arrowclosed"},"data":{"operationType":"Find","linkType":"natural"},"assetUid":"019cfcde-53fa-741b-8d31-756628b77bb4","selected":true}}}	1	2026-03-17 17:54:59.634+00
126	019cfcf0-25ef-718d-91b5-78e27ef3697a	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-603.1038999716029,"y":211.5024741307078},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-603.1038999716029,"y":211.5024741307078},"dragging":false}}}	1	2026-03-17 17:55:22.735+00
127	019cfcf0-25f9-7598-8745-ac3fdb06b79f	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-594.3243055983809,"y":-100.52197985756214},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-594.3243055983809,"y":-100.52197985756214},"dragging":true}}}	1	2026-03-17 17:55:22.745+00
128	019cfcf0-25fd-77df-bc17-648ea7979114	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-54.83389602021464,"y":-111.83445266265511},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-54.83389602021464,"y":-111.83445266265511},"dragging":false}}}	1	2026-03-17 17:55:22.749+00
129	019cfcf0-2601-76c6-b133-109ef864f842	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-960.4065885105807,"y":-59.14110311681385},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-960.4065885105807,"y":-59.14110311681385},"dragging":true}}}	1	2026-03-17 17:55:22.753+00
130	019cfcf0-2a08-7442-bec7-422eeb3da914	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1004.2094703471826,"y":240.541791442967},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1004.2094703471826,"y":240.541791442967},"dragging":true}}}	1	2026-03-17 17:55:23.784+00
131	019cfcf0-2a09-764e-a233-9d30c0fd74e5	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-455.9394663957943,"y":-82.79513535039594},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-455.9394663957943,"y":-82.79513535039594},"dragging":true}}}	1	2026-03-17 17:55:23.785+00
132	019cfcf0-2a09-764e-a233-a391fe86055c	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1361.5121588861605,"y":-30.101785804554694},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1361.5121588861605,"y":-30.101785804554694},"dragging":true}}}	1	2026-03-17 17:55:23.785+00
133	019cfcf0-2d77-766d-90fb-dcf1fb35d378	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-467.73668905389957,"y":-80.98017801837975},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-467.73668905389957,"y":-80.98017801837975},"dragging":false}}}	1	2026-03-17 17:55:24.663+00
134	019cfcf0-2d7c-72a9-ae37-d5138aeefec1	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1016.0066930052878,"y":242.35674877498317},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1016.0066930052878,"y":242.35674877498317},"dragging":false}}}	1	2026-03-17 17:55:24.668+00
135	019cfcf0-2dc4-708e-9b41-6c991de71bb7	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1373.3093815442658,"y":-28.286828472538502},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1373.3093815442658,"y":-28.286828472538502},"dragging":false}}}	1	2026-03-17 17:55:24.74+00
136	019cfcf0-35f0-71ad-9e8f-1e42b08b805f	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-983.3374610289962,"y":146.1640101781247},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-983.3374610289962,"y":146.1640101781247},"dragging":true}}}	1	2026-03-17 17:55:26.832+00
137	019cfcf0-35f1-73a9-9e90-a1a2a4196704	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1340.6401495679743,"y":-124.47956706939698},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1340.6401495679743,"y":-124.47956706939698},"dragging":true}}}	1	2026-03-17 17:55:26.833+00
138	019cfcf0-38d6-751c-9d8c-d7d226c652f2	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1340.6401495679743,"y":-124.47956706939698},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1340.6401495679743,"y":-124.47956706939698},"dragging":false}}}	1	2026-03-17 17:55:27.574+00
139	019cfcf0-38d6-751c-9d8c-d93c8b644d23	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-983.3374610289962,"y":146.1640101781247},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-983.3374610289962,"y":146.1640101781247},"dragging":false}}}	1	2026-03-17 17:55:27.574+00
140	019cfcf0-3f8a-7359-a87f-0ec31abb486c	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1337.0102349039419,"y":-163.5011497077452},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1337.0102349039419,"y":-163.5011497077452},"dragging":true}}}	1	2026-03-17 17:55:29.29+00
141	019cfcf0-4b69-72a5-ba0f-22c5a30c6138	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1430.568593129644,"y":-211.82249956058035},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1430.568593129644,"y":-211.82249956058035},"dragging":true}}}	1	2026-03-17 17:55:32.329+00
142	019cfcf0-9173-72ef-896b-e615b4ed04e5	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-467.73668905389957,"y":-80.98017801837975},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-467.73668905389957,"y":-80.98017801837975},"dragging":false}}}	1	2026-03-17 17:55:50.259+00
143	019cfcf0-9174-7574-8b94-9537d57014c6	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-983.3374610289962,"y":146.1640101781247},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-983.3374610289962,"y":146.1640101781247},"dragging":false}}}	1	2026-03-17 17:55:50.26+00
144	019cfcf0-9178-7172-91c5-331f266aec3f	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1430.568593129644,"y":-211.82249956058035},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1430.568593129644,"y":-211.82249956058035},"dragging":true}}}	1	2026-03-17 17:55:50.264+00
145	019cfcf0-9179-7518-8626-1beaf6c11493	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-594.3243055983809,"y":-100.52197985756214},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-594.3243055983809,"y":-100.52197985756214},"dragging":true}}}	1	2026-03-17 17:55:50.265+00
146	019cfcf0-9bfb-7316-a14d-ca7eba711702	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-467.73668905389957,"y":-80.98017801837975},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-467.73668905389957,"y":-80.98017801837975},"dragging":false}}}	1	2026-03-17 17:55:52.955+00
147	019cfcf0-9bfc-720c-bb16-afc89b25828b	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1430.568593129644,"y":-211.82249956058035},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1430.568593129644,"y":-211.82249956058035},"dragging":false}}}	1	2026-03-17 17:55:52.956+00
148	019cfcf0-9bfc-720c-bb16-b3957e71b4f8	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-594.3243055983809,"y":-100.52197985756214},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-594.3243055983809,"y":-100.52197985756214},"dragging":false}}}	1	2026-03-17 17:55:52.956+00
149	019cfcf0-a057-755a-856c-b307e4df84ce	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1682.9048857703253,"y":-209.918074710462},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1682.9048857703253,"y":-209.918074710462},"dragging":true}}}	1	2026-03-17 17:55:54.071+00
150	019cfcf0-a059-75ec-a7a3-9b67d3052e99	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-720.072981694581,"y":-79.0757531682614},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-720.072981694581,"y":-79.0757531682614},"dragging":true}}}	1	2026-03-17 17:55:54.073+00
151	019cfcf0-a3ee-733f-a5bf-257364937005	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-720.072981694581,"y":-79.0757531682614},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-720.072981694581,"y":-79.0757531682614},"dragging":false}}}	1	2026-03-17 17:55:54.99+00
152	019cfcf0-a3ef-703e-bb6a-eb73b5bb089f	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1682.9048857703253,"y":-209.918074710462},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1682.9048857703253,"y":-209.918074710462},"dragging":false}}}	1	2026-03-17 17:55:54.991+00
153	019cfcf1-2e2b-70f9-a6dc-586b453e3ff6	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-899.7005435769267,"y":-113.74072125081938},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-899.7005435769267,"y":-113.74072125081938},"dragging":true}}}	1	2026-03-17 17:56:30.379+00
154	019cfcf1-2e2c-75a4-9748-2f0e1e3ee66b	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1862.532447652671,"y":-244.58304279301996},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1862.532447652671,"y":-244.58304279301996},"dragging":true}}}	1	2026-03-17 17:56:30.38+00
155	019cfcf1-2e2c-75a4-9748-28d2177ade62	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-773.9518674807266,"y":-135.1869479401201},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-773.9518674807266,"y":-135.1869479401201},"dragging":true}}}	1	2026-03-17 17:56:30.38+00
156	019cfcf1-2e2d-7218-8e8e-98416d931683	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1162.965022911342,"y":111.49904209556675},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1162.965022911342,"y":111.49904209556675},"dragging":true}}}	1	2026-03-17 17:56:30.381+00
157	019cfcf1-3848-761d-b2fa-3ca12d8aec05	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-955.0697679680285,"y":-134.50418039748257},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-955.0697679680285,"y":-134.50418039748257},"dragging":true}}}	1	2026-03-17 17:56:32.968+00
158	019cfcf1-3848-761d-b2fa-40b510250ad5	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-829.3210918718283,"y":-155.9504070867833},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-829.3210918718283,"y":-155.9504070867833},"dragging":true}}}	1	2026-03-17 17:56:32.968+00
159	019cfcf1-384d-706b-93a6-1db08d76cb81	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1218.3342473024438,"y":90.73558294890357},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1218.3342473024438,"y":90.73558294890357},"dragging":true}}}	1	2026-03-17 17:56:32.973+00
160	019cfcf1-384f-708e-b195-da584b0b1891	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1917.9016720437728,"y":-265.34650193968315},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1917.9016720437728,"y":-265.34650193968315},"dragging":true}}}	1	2026-03-17 17:56:32.975+00
161	019cfcf1-415f-72d5-8fa0-634eb291fb55	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-1337.463473919075,"y":-492.6738506774222},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1337.463473919075,"y":-492.6738506774222},"dragging":true}}}	1	2026-03-17 17:56:35.295+00
162	019cfcf1-4470-75fa-bbae-2f7a3b6ed249	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-1337.463473919075,"y":-492.6738506774222},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1337.463473919075,"y":-492.6738506774222},"dragging":false}}}	1	2026-03-17 17:56:36.08+00
163	019cfcf1-48ba-764e-87c1-9048e1f950c9	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-829.3210918718283,"y":-155.9504070867833},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-829.3210918718283,"y":-155.9504070867833},"dragging":false}}}	1	2026-03-17 17:56:37.178+00
164	019cfcf1-4d63-73dc-8b06-7aa3db2f77d6	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-827.5908036096064,"y":-155.9504070867833},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-827.5908036096064,"y":-155.9504070867833},"dragging":true}}}	1	2026-03-17 17:56:38.371+00
165	019cfcf1-5143-75d9-867b-0afa6abf4a5e	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-825.8605153473843,"y":-155.9504070867833},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-825.8605153473843,"y":-155.9504070867833},"dragging":true}}}	1	2026-03-17 17:56:39.363+00
166	019cfcf1-588e-755f-9c29-e4a3773a92ff	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1218.3342473024438,"y":90.73558294890357},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1218.3342473024438,"y":90.73558294890357},"dragging":false}}}	1	2026-03-17 17:56:41.23+00
167	019cfcf1-5e0f-7459-8231-3aa368685eb4	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-1021.3830889784624,"y":-252.8465497712114},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1021.3830889784624,"y":-252.8465497712114},"dragging":true}}}	1	2026-03-17 17:56:42.639+00
168	019cfcf1-b007-778c-9363-f7daae815dce	1	1	asset_updated	{"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","changes":{"configs":{"id":"model-1773768842045","type":"model","position":{"x":-1021.3830889784624,"y":-252.8465497712114},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768842045"},"assetUid":"019cfcdc-9b53-7728-a2e2-374ab2967015","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1021.3830889784624,"y":-252.8465497712114},"dragging":false}}}	1	2026-03-17 17:57:03.623+00
169	019cfcf2-38ac-7058-903b-268c6f72ba62	1	1	asset_updated	{"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","changes":{"configs":{"id":"op-1773768840998","type":"operation","position":{"x":-1917.9016720437728,"y":-265.34650193968315},"data":{"method":"Get","suffix":"","id":"op-1773768840998"},"assetUid":"019cfcdc-972d-7222-b0ca-a046fe152dee","width":256,"height":173,"selected":true,"positionAbsolute":{"x":-1917.9016720437728,"y":-265.34650193968315},"dragging":true}}}	1	2026-03-17 17:57:38.604+00
170	019cfcf2-6ab6-7694-8bb9-a9bfa834825f	1	1	asset_updated	{"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","changes":{"configs":{"id":"model-1773768890166","type":"model","position":{"x":-1218.3342473024438,"y":90.73558294890357},"data":{"modelName":"User","outputs":{},"filters":{},"id":"model-1773768890166"},"assetUid":"019cfcdd-5741-720d-ab62-22bcc782765f","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1218.3342473024438,"y":90.73558294890357},"dragging":false}}}	1	2026-03-17 17:57:51.414+00
171	019cfcf2-89d1-7002-bacd-171812a8eef0	1	1	asset_updated	{"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","changes":{"configs":{"id":"model-1773768893974","type":"model","position":{"x":-1337.463473919075,"y":-492.6738506774222},"data":{"modelName":"Profile","outputs":{},"filters":{},"id":"model-1773768893974"},"assetUid":"019cfcdd-661d-74ca-b092-382c3201efc5","width":256,"height":214,"selected":true,"positionAbsolute":{"x":-1337.463473919075,"y":-492.6738506774222},"dragging":false}}}	1	2026-03-17 17:57:59.377+00
\.


--
-- TOC entry 3526 (class 0 OID 115424)
-- Dependencies: 226
-- Data for Name: invites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invites (id, uid, token, project_id, created_by, role, expires_at, created_at, used_at, used_by) FROM stdin;
\.


--
-- TOC entry 3520 (class 0 OID 115393)
-- Dependencies: 220
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, uid, name, owner_id, status, created_at, created_by, updated_at, updated_by) FROM stdin;
1	019cfc5a-e9d9-72b8-b27b-a7dfbb87c3a0	Siage	1	1	2026-03-17 15:12:22.489+00	1	2026-03-17 15:12:22.489+00	1
2	019cfc5c-2db3-72d6-b1d7-16a8f6a58c40	S1	1	1	2026-03-17 15:13:45.395+00	1	2026-03-17 15:13:45.395+00	1
3	019cfc5c-b0b4-71fb-8c0a-4a3f4d834102	s3	1	1	2026-03-17 15:14:18.932+00	1	2026-03-17 15:14:18.932+00	1
\.


--
-- TOC entry 3518 (class 0 OID 115382)
-- Dependencies: 218
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, uid, name, email, password, avatar, role, status, created_at, updated_at, created_by, updated_by) FROM stdin;
1	019cfc46-94eb-723b-9f17-f1d52847d467	Administrador	admin@example.com	$2b$10$uQK/kHpoBm9iYd2HFHWxXeCnKw3yuYsvZ7xZKaUgUGQ4czRY8TjQu	\N	user	1	2026-03-17 14:50:10.027+00	2026-03-17 14:50:10.027+00	\N	\N
\.


--
-- TOC entry 3515 (class 0 OID 66118)
-- Dependencies: 215
-- Data for Name: migration; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.migration (sid, date) FROM stdin;
a3rpobf0	2026-03-17 12:50:27.355944+00
7q57cgde	2026-03-17 16:05:50.199653+00
\.


--
-- TOC entry 3516 (class 0 OID 66126)
-- Dependencies: 216
-- Data for Name: revision; Type: TABLE DATA; Schema: sys; Owner: -
--

COPY sys.revision (hash, migration_sid, date, operation, relation, revision) FROM stdin;
d7e887a76e12c09a3678661b4990fb3a:e1cdcce75b4563f618e485454b6815dd8f64f3668e2d986a46fecfd238f7bbed	a3rpobf0	2026-03-17 12:50:27.385383+00	restore:data-"public"."users"	"public"."users"	\N
d7e887a76e12c09a3678661b4990fb3a:3b3d4ff29dd00e4918c50e12030a6d236f9aeaa1c9a3c7e55f7527911efd16fb	a3rpobf0	2026-03-17 12:50:27.38722+00	restore:data-"public"."projects"	"public"."projects"	\N
d7e887a76e12c09a3678661b4990fb3a:e3b14f40b30a0d9549ed21c976f3f0ff5f2b789cbc5843d7847efd371daf8b34	a3rpobf0	2026-03-17 12:50:27.388445+00	restore:data-"public"."collaborators"	"public"."collaborators"	\N
d7e887a76e12c09a3678661b4990fb3a:8e5632b2e35c0a24fd2ac367c1c6ea399134bf0a14e1559b4c03832d7120b871	a3rpobf0	2026-03-17 12:50:27.389748+00	restore:data-"public"."assets"	"public"."assets"	\N
d7e887a76e12c09a3678661b4990fb3a:391ca5ec35f269b55c907b0dfac43a4cbf2083344e9caecd7cf16f4e0ddef1b5	a3rpobf0	2026-03-17 12:50:27.391114+00	restore:data-"public"."invites"	"public"."invites"	\N
d7e887a76e12c09a3678661b4990fb3a:511485b6130b7483446f2e0cf53b3524c18192ac2f5377d86fa08320b9bfbcd1	a3rpobf0	2026-03-17 12:50:27.392863+00	restore:data-"public"."contributions"	"public"."contributions"	\N
81c05001192c6b08ddf60de4e1d93fcb:e1cdcce75b4563f618e485454b6815dd8f64f3668e2d986a46fecfd238f7bbed	7q57cgde	2026-03-17 16:05:50.229667+00	restore:data-"public"."users"	"public"."users"	\N
81c05001192c6b08ddf60de4e1d93fcb:3b3d4ff29dd00e4918c50e12030a6d236f9aeaa1c9a3c7e55f7527911efd16fb	7q57cgde	2026-03-17 16:05:50.233478+00	restore:data-"public"."projects"	"public"."projects"	\N
81c05001192c6b08ddf60de4e1d93fcb:e3b14f40b30a0d9549ed21c976f3f0ff5f2b789cbc5843d7847efd371daf8b34	7q57cgde	2026-03-17 16:05:50.236761+00	restore:data-"public"."collaborators"	"public"."collaborators"	\N
81c05001192c6b08ddf60de4e1d93fcb:8e5632b2e35c0a24fd2ac367c1c6ea399134bf0a14e1559b4c03832d7120b871	7q57cgde	2026-03-17 16:05:50.241915+00	restore:data-"public"."assets"	"public"."assets"	\N
81c05001192c6b08ddf60de4e1d93fcb:391ca5ec35f269b55c907b0dfac43a4cbf2083344e9caecd7cf16f4e0ddef1b5	7q57cgde	2026-03-17 16:05:50.244672+00	restore:data-"public"."invites"	"public"."invites"	\N
81c05001192c6b08ddf60de4e1d93fcb:511485b6130b7483446f2e0cf53b3524c18192ac2f5377d86fa08320b9bfbcd1	7q57cgde	2026-03-17 16:05:50.246884+00	restore:data-"public"."contributions"	"public"."contributions"	\N
\.


--
-- TOC entry 3542 (class 0 OID 0)
-- Dependencies: 217
-- Name: temp_0_users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_0_users_id_seq', 2, false);


--
-- TOC entry 3543 (class 0 OID 0)
-- Dependencies: 219
-- Name: temp_1_projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_1_projects_id_seq', 4, false);


--
-- TOC entry 3544 (class 0 OID 0)
-- Dependencies: 221
-- Name: temp_2_collaborators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_2_collaborators_id_seq', 4, false);


--
-- TOC entry 3545 (class 0 OID 0)
-- Dependencies: 223
-- Name: temp_3_assets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_3_assets_id_seq', 24, true);


--
-- TOC entry 3546 (class 0 OID 0)
-- Dependencies: 225
-- Name: temp_4_invites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_4_invites_id_seq', 1, false);


--
-- TOC entry 3547 (class 0 OID 0)
-- Dependencies: 227
-- Name: temp_5_contributions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.temp_5_contributions_id_seq', 171, true);


--
-- TOC entry 3346 (class 2606 OID 115450)
-- Name: assets pk_assets_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT pk_assets_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3340 (class 2606 OID 115448)
-- Name: collaborators pk_collaborators_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT pk_collaborators_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3358 (class 2606 OID 115454)
-- Name: contributions pk_contributions_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT pk_contributions_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3352 (class 2606 OID 115452)
-- Name: invites pk_invites_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT pk_invites_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3334 (class 2606 OID 115446)
-- Name: projects pk_projects_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT pk_projects_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3328 (class 2606 OID 115444)
-- Name: users pk_users_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT pk_users_id_by_prisma PRIMARY KEY (id);


--
-- TOC entry 3348 (class 2606 OID 115470)
-- Name: assets uk_assets_project_id_path_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT uk_assets_project_id_path_by_prisma UNIQUE (project_id, path);


--
-- TOC entry 3350 (class 2606 OID 115468)
-- Name: assets uk_assets_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT uk_assets_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3342 (class 2606 OID 115464)
-- Name: collaborators uk_collaborators_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT uk_collaborators_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3344 (class 2606 OID 115466)
-- Name: collaborators uk_collaborators_user_id_project_id_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT uk_collaborators_user_id_project_id_by_prisma UNIQUE (user_id, project_id);


--
-- TOC entry 3360 (class 2606 OID 115476)
-- Name: contributions uk_contributions_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT uk_contributions_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3354 (class 2606 OID 115474)
-- Name: invites uk_invites_token_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT uk_invites_token_by_prisma UNIQUE (token);


--
-- TOC entry 3356 (class 2606 OID 115472)
-- Name: invites uk_invites_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT uk_invites_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3336 (class 2606 OID 115462)
-- Name: projects uk_projects_name_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uk_projects_name_by_prisma UNIQUE (name);


--
-- TOC entry 3338 (class 2606 OID 115460)
-- Name: projects uk_projects_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT uk_projects_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3330 (class 2606 OID 115458)
-- Name: users uk_users_email_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_users_email_by_prisma UNIQUE (email);


--
-- TOC entry 3332 (class 2606 OID 115456)
-- Name: users uk_users_uid_by_prisma; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uk_users_uid_by_prisma UNIQUE (uid);


--
-- TOC entry 3324 (class 2606 OID 66125)
-- Name: migration migration_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.migration
    ADD CONSTRAINT migration_pkey PRIMARY KEY (sid);


--
-- TOC entry 3326 (class 2606 OID 66133)
-- Name: revision revision_pkey; Type: CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_pkey PRIMARY KEY (hash);


--
-- TOC entry 3365 (class 2606 OID 115502)
-- Name: assets AssetChildren; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "AssetChildren" FOREIGN KEY (parent_id) REFERENCES public.assets(id);


--
-- TOC entry 3366 (class 2606 OID 115492)
-- Name: assets AssetOwner; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "AssetOwner" FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- TOC entry 3367 (class 2606 OID 115497)
-- Name: assets AssetsProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.assets
    ADD CONSTRAINT "AssetsProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3363 (class 2606 OID 115482)
-- Name: collaborators CollaboratorProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT "CollaboratorProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3364 (class 2606 OID 115487)
-- Name: collaborators CollaboratorUser; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.collaborators
    ADD CONSTRAINT "CollaboratorUser" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3371 (class 2606 OID 115527)
-- Name: contributions ContributionToProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT "ContributionToProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3372 (class 2606 OID 115522)
-- Name: contributions Contributor; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contributions
    ADD CONSTRAINT "Contributor" FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- TOC entry 3368 (class 2606 OID 115512)
-- Name: invites InviteCreator; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteCreator" FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- TOC entry 3369 (class 2606 OID 115507)
-- Name: invites InviteToProject; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteToProject" FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- TOC entry 3370 (class 2606 OID 115517)
-- Name: invites InviteUsedBy; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invites
    ADD CONSTRAINT "InviteUsedBy" FOREIGN KEY (used_by) REFERENCES public.users(id);


--
-- TOC entry 3362 (class 2606 OID 115477)
-- Name: projects Owner; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT "Owner" FOREIGN KEY (owner_id) REFERENCES public.users(id);


--
-- TOC entry 3361 (class 2606 OID 66134)
-- Name: revision revision_migration_sid_fkey; Type: FK CONSTRAINT; Schema: sys; Owner: -
--

ALTER TABLE ONLY sys.revision
    ADD CONSTRAINT revision_migration_sid_fkey FOREIGN KEY (migration_sid) REFERENCES sys.migration(sid);


--
-- TOC entry 3535 (class 0 OID 0)
-- Dependencies: 5
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


-- Completed on 2026-03-17 18:01:22 GMT

--
-- PostgreSQL database dump complete
--

\unrestrict x8gx5ct0mFM9zMO5WPBteX4OvCT3SFOCXqzvbe3ezScLui440Ck1YtTeRIjk2kn

